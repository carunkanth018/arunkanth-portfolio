import React, { useState } from 'react';
import { Mail, Github, Linkedin, Terminal, Send, CheckCircle, ShieldCheck, MapPin, Globe } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [engagement, setEngagement] = useState('Staff/Principal ML Role');
  const [specs, setSpecs] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubmitted(true);
  };

  return (
    <section id="contact" className="relative w-full py-20 md:py-28 bg-[#0A0A0A] border-b border-white/10 overflow-hidden">
      {/* Ghost Backdrop Typography Watermark */}
      <div className="absolute left-0 top-10 opacity-5 pointer-events-none select-none z-0">
        <span className="font-ghost-watermark text-[140px] sm:text-[220px] md:text-[300px] text-white tracking-tighter">
          CONNECT
        </span>
      </div>

      <div className="relative z-10 max-w-[1280px] mx-auto px-4 md:px-8 flex flex-col gap-12">
        {/* Header */}
        <div className="flex flex-col gap-3">
          <span className="font-mono text-[11px] text-gray-400 uppercase tracking-[0.3em] font-bold">
            06 // CONTACT &amp; INITIATION TERMINAL
          </span>
          <h2 className="font-headline-lg text-[#F5F5F5] uppercase">
            Initialize Technical Handshake
          </h2>
          <div className="h-[1px] w-24 bg-white/20 mt-1" />
          <p className="font-sans text-[0.9375rem] text-gray-400 max-w-2xl">
            Open to senior/staff data science, principal data architecture, and quantitative advisory
            consultations on high-throughput ML pipelines.
          </p>
        </div>

        {/* Grid: Coordinates on Left (5 cols) + Dispatch Terminal on Right (7 cols) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Coordinates Column */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            {/* Direct Comms Box */}
            <div className="p-6 bg-white/5 border border-white/10 hover:border-white/30 transition-all flex flex-col gap-4">
              <div className="flex items-center gap-2 text-white font-mono text-xs uppercase tracking-wider font-bold pb-2 border-b border-white/10">
                <Mail className="w-4 h-4 text-white" />
                <span>Direct Communications</span>
              </div>
              <div className="flex flex-col gap-1 font-mono text-sm">
                <a
                  href="mailto:alex.rivas.analytics@gmail.com"
                  className="text-white hover:text-gray-300 transition-colors break-all font-bold"
                >
                  alex.rivas.analytics@gmail.com
                </a>
                <span className="text-[10px] text-gray-400 flex items-center gap-1.5 mt-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#a8ffd2]" />
                  SECURE_FINGERPRINT: 4A8F-912E-C5B1-7890
                </span>
              </div>
            </div>

            {/* Repositories & Profiles Box */}
            <div className="p-6 bg-white/5 border border-white/10 hover:border-white/30 transition-all flex flex-col gap-4">
              <div className="flex items-center gap-2 text-white font-mono text-xs uppercase tracking-wider font-bold pb-2 border-b border-white/10">
                <Globe className="w-4 h-4 text-white" />
                <span>Repositories &amp; Profiles</span>
              </div>
              <div className="grid grid-cols-2 gap-2 font-mono text-xs">
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 bg-black/40 hover:bg-white hover:text-black text-gray-300 border border-white/10 transition-colors flex items-center gap-2 font-bold uppercase tracking-wider"
                >
                  <Github className="w-3.5 h-3.5" />
                  <span>GitHub</span>
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 bg-black/40 hover:bg-white hover:text-black text-gray-300 border border-white/10 transition-colors flex items-center gap-2 font-bold uppercase tracking-wider"
                >
                  <Linkedin className="w-3.5 h-3.5" />
                  <span>LinkedIn</span>
                </a>
                <a
                  href="https://kaggle.com"
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 bg-black/40 hover:bg-white hover:text-black text-gray-300 border border-white/10 transition-colors flex items-center gap-2 font-bold uppercase tracking-wider"
                >
                  <Terminal className="w-3.5 h-3.5" />
                  <span>Kaggle</span>
                </a>
                <a
                  href="https://scholar.google.com"
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 bg-black/40 hover:bg-white hover:text-black text-gray-300 border border-white/10 transition-colors flex items-center gap-2 font-bold uppercase tracking-wider"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Scholar</span>
                </a>
              </div>
            </div>

            {/* Handshake Vitals */}
            <div className="p-5 bg-black/40 border border-white/10 flex flex-col gap-2.5 font-mono text-xs">
              <div className="flex items-center justify-between text-gray-400">
                <span className="font-bold uppercase tracking-wider">LOCATION:</span>
                <span className="text-white flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-white" />
                  SAN FRANCISCO, CA (REMOTE/HYBRID)
                </span>
              </div>
              <div className="flex items-center justify-between text-gray-400">
                <span className="font-bold uppercase tracking-wider">TELEMETRY PING:</span>
                <span className="text-[#a8ffd2] font-bold">24ms • OPTIMAL</span>
              </div>
              <div className="flex items-center justify-between text-gray-400">
                <span className="font-bold uppercase tracking-wider">AVAILABILITY:</span>
                <span className="text-white font-bold uppercase">IMMEDIATE / Q2-Q3</span>
              </div>
            </div>
          </div>

          {/* Dispatch Terminal (7 cols) */}
          <div className="lg:col-span-7 p-6 md:p-8 bg-white/5 border border-white/10 flex flex-col gap-6">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 bg-white animate-pulse" />
                <span className="font-mono text-xs text-white font-bold uppercase tracking-wider">
                  TRANSMISSION_TERMINAL // DISPATCH_PACKET
                </span>
              </div>
              <span className="font-mono text-[10px] text-gray-400 font-bold tracking-widest bg-white/10 px-2 py-0.5 border border-white/20">
                SSL 256-BIT ENCRYPTED
              </span>
            </div>

            {submitted ? (
              <div className="p-8 bg-black/60 border border-white/20 flex flex-col items-center text-center gap-4 animate-fadeIn">
                <CheckCircle className="w-12 h-12 text-[#a8ffd2]" />
                <div className="flex flex-col gap-1">
                  <h3 className="font-headline-sm text-lg text-[#F5F5F5] uppercase">
                    TRANSMISSION PACKET DISPATCHED
                  </h3>
                  <p className="font-mono text-xs text-gray-400">
                    Checksum verified: <span className="text-white font-bold">0x9E71F02</span>
                  </p>
                  <p className="font-sans text-xs text-gray-400 max-w-sm mt-2">
                    Your transmission payload has been routed to Alexander's primary telemetry queue.
                    Expect an acknowledgment response within 24 operational hours.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setName('');
                    setEmail('');
                    setSpecs('');
                  }}
                  className="px-5 py-2.5 bg-white text-black font-mono text-xs uppercase font-bold tracking-[0.2em] hover:bg-neutral-200 transition-colors mt-2"
                >
                  Send Another Transmission
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[10px] text-gray-400 uppercase font-bold tracking-wider">
                      OPERATOR NAME / ENTITY
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Dr. Elena Vance / DeepMind"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="px-3.5 py-2.5 bg-black/60 border border-white/10 text-[#F5F5F5] font-sans text-sm focus:outline-none focus:border-white transition-colors"
                    />
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[10px] text-gray-400 uppercase font-bold tracking-wider">
                      TRANSMISSION ADDRESS (EMAIL)
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="elena@enterprise.org"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="px-3.5 py-2.5 bg-black/60 border border-white/10 text-[#F5F5F5] font-sans text-sm focus:outline-none focus:border-white transition-colors"
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[10px] text-gray-400 uppercase font-bold tracking-wider">
                    ENGAGEMENT ARCHITECTURE
                  </label>
                  <select
                    value={engagement}
                    onChange={(e) => setEngagement(e.target.value)}
                    className="px-3.5 py-2.5 bg-black/60 border border-white/10 text-[#F5F5F5] font-mono text-xs focus:outline-none focus:border-white transition-colors"
                  >
                    <option value="Staff/Principal ML Role">Staff / Principal Machine Learning Role</option>
                    <option value="Data Architecture Advisory">Data Architecture Advisory / Consulting</option>
                    <option value="Fractional Head of Data">Fractional Head of Data / ML Systems</option>
                    <option value="Research & Methodology Review">Research &amp; Methodology Review</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[10px] text-gray-400 uppercase font-bold tracking-wider">
                    TECHNICAL SPECIFICATIONS / OBJECTIVE
                  </label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Provide context regarding data volume, latency constraints, team topology, or project requirements..."
                    value={specs}
                    onChange={(e) => setSpecs(e.target.value)}
                    className="px-3.5 py-2.5 bg-black/60 border border-white/10 text-[#F5F5F5] font-sans text-sm focus:outline-none focus:border-white transition-colors resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="mt-2 w-full py-3.5 bg-white text-black font-mono text-xs font-bold uppercase tracking-[0.2em] hover:bg-neutral-200 transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>TRANSMIT INQUIRY PACKET</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
