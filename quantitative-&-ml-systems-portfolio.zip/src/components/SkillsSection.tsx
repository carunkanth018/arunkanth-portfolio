import React, { useState, useEffect } from 'react';
import { Brain, Terminal, GitBranch, BarChart3, RefreshCw, Play, CheckCircle2 } from 'lucide-react';

export const SkillsSection: React.FC = () => {
  const [logs, setLogs] = useState<
    { timestamp: string; level: 'INFO' | 'SUCCESS' | 'BENCH' | 'OUTPUT'; message: string }[]
  >([
    {
      timestamp: '2025-05-14T09:12:04.102Z',
      level: 'INFO',
      message: 'Initializing Polars LazyFrame context on 128 cores...',
    },
    {
      timestamp: '2025-05-14T09:12:04.221Z',
      level: 'INFO',
      message: 'Delta table partitioned by `utc_hour`: 450,192,840 records discovered.',
    },
    {
      timestamp: '2025-05-14T09:12:04.810Z',
      level: 'SUCCESS',
      message: 'Vector normalizer cached in 14.2ms. Convergence metric epsilon < 1e-6.',
    },
    {
      timestamp: '2025-05-14T09:12:05.004Z',
      level: 'BENCH',
      message: 'Triton ONNX Engine: Batch size 2048 dispatched. Latency P99: 18.19ms.',
    },
    {
      timestamp: '2025-05-14T09:12:05.101Z',
      level: 'OUTPUT',
      message: 'Model deployment validated: `model_v4_telemetry_prod` loaded to production cluster.',
    },
  ]);

  const [isAuditing, setIsAuditing] = useState(false);

  const triggerAudit = () => {
    setIsAuditing(true);
    const now = new Date().toISOString();
    const newLogs = [
      { timestamp: now, level: 'INFO' as const, message: 'Initiating telemetry pipeline self-diagnostic...' },
      { timestamp: now, level: 'INFO' as const, message: 'Auditing 14 dbt models against Snowflake production schemas.' },
      { timestamp: now, level: 'SUCCESS' as const, message: 'Zero schema drifts detected across 450M daily events.' },
      { timestamp: now, level: 'BENCH' as const, message: 'Kafka lag: 0.12ms | Memory headroom: 68.4% | Thread utilization: Nominal.' },
      { timestamp: now, level: 'OUTPUT' as const, message: 'Diagnostic exit code 0: Production cluster fully compliant.' },
    ];
    setTimeout(() => {
      setLogs(newLogs);
      setIsAuditing(false);
    }, 600);
  };

  return (
    <section id="skills" className="relative w-full py-20 md:py-28 bg-[#0A0A0A] border-b border-white/10 overflow-hidden">
      {/* Ghost Backdrop Typography Watermark */}
      <div className="absolute left-0 top-8 opacity-5 pointer-events-none select-none z-0">
        <span className="font-ghost-watermark text-[140px] sm:text-[220px] md:text-[300px] text-white tracking-tighter">
          MATRIX
        </span>
      </div>

      <div className="relative z-10 max-w-[1280px] mx-auto px-4 md:px-8 flex flex-col gap-12">
        {/* Section Header */}
        <div className="flex flex-col gap-3">
          <span className="font-mono text-[11px] text-gray-400 uppercase tracking-[0.3em] font-bold">
            02 // TECHNICAL TAXONOMY &amp; CAPABILITY MATRIX
          </span>
          <h2 className="font-headline-lg text-[#F5F5F5] uppercase">
            Calibrated Stack &amp; Engineering Disciplines
          </h2>
          <div className="h-[1px] w-24 bg-white/20 mt-1" />
          <p className="font-sans text-[0.9375rem] text-gray-400 max-w-2xl">
            Categorized across production deployment lifecycles. No arbitrary percentage bars—each
            competency is verified by production SLA standards and architectural rigor.
          </p>
        </div>

        {/* Domain Matrix Grid (4 Grid Columns) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* 1. ML & Statistics */}
          <div className="p-5 bg-white/5 border border-white/10 flex flex-col gap-4 hover:border-white/30 transition-colors">
            <div className="flex items-center gap-2 text-white pb-2 border-b border-white/10">
              <Brain className="w-5 h-5 text-white" />
              <h3 className="font-headline-sm uppercase text-[#F5F5F5]">ML &amp; Statistics</h3>
            </div>
            <div className="flex flex-col gap-2">
              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Deep Learning &amp; Transformers
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 1
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  PyTorch, TorchVision, LoRA fine-tuning
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Bayesian &amp; Causal Inference
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 1
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  PyMC, Stan, DoWhy, Propensity Matching
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Time-Series &amp; Drift
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 1
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  ARIMA, Prophet, DeepAR, Evidentially
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Dimensionality Reduction
                  </span>
                  <span className="font-mono text-[10px] text-gray-400 bg-white/5 px-1.5 py-0.5 border border-white/10 font-bold">
                    TIER 2
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  PCA, t-SNE, UMAP, Autoencoders
                </span>
              </div>
            </div>
          </div>

          {/* 2. Computation */}
          <div className="p-5 bg-white/5 border border-white/10 flex flex-col gap-4 hover:border-white/30 transition-colors">
            <div className="flex items-center gap-2 text-white pb-2 border-b border-white/10">
              <Terminal className="w-5 h-5 text-white" />
              <h3 className="font-headline-sm uppercase text-[#F5F5F5]">Computation</h3>
            </div>
            <div className="flex flex-col gap-2">
              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Python Runtime Stack
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 1
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  Polars, NumPy, Numba, Cython
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Modern SQL Dialects
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 1
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  Snowflake SQL, BigQuery, PostgreSQL, DuckDB
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Rust / C++ (High Throughput)
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 2
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  Memory-safe telemetry ingest agents
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    R (Biostats / Econometrics)
                  </span>
                  <span className="font-mono text-[10px] text-gray-400 bg-white/5 px-1.5 py-0.5 border border-white/10 font-bold">
                    TIER 2
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  tidyverse, ggplot2, fixest
                </span>
              </div>
            </div>
          </div>

          {/* 3. Data Engineering */}
          <div className="p-5 bg-white/5 border border-white/10 flex flex-col gap-4 hover:border-white/30 transition-colors">
            <div className="flex items-center gap-2 text-white pb-2 border-b border-white/10">
              <GitBranch className="w-5 h-5 text-white" />
              <h3 className="font-headline-sm uppercase text-[#F5F5F5]">Data Engineering</h3>
            </div>
            <div className="flex flex-col gap-2">
              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Apache Spark &amp; Databricks
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 1
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  PySpark, Delta Lake, Spark Streaming
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    dbt &amp; Metric Layers
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 1
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  Semantic layers, testing macros, CI/CD
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Streaming Orchestration
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 1
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  Kafka, Airflow, Prefect, Dagster
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Open Lakehouse Specs
                  </span>
                  <span className="font-mono text-[10px] text-gray-400 bg-white/5 px-1.5 py-0.5 border border-white/10 font-bold">
                    TIER 2
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  Apache Iceberg, Parquet metadata
                </span>
              </div>
            </div>
          </div>

          {/* 4. Visualization */}
          <div className="p-5 bg-white/5 border border-white/10 flex flex-col gap-4 hover:border-white/30 transition-colors">
            <div className="flex items-center gap-2 text-white pb-2 border-b border-white/10">
              <BarChart3 className="w-5 h-5 text-white" />
              <h3 className="font-headline-sm uppercase text-[#F5F5F5]">Visualization</h3>
            </div>
            <div className="flex flex-col gap-2">
              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    D3.js &amp; Custom WebGL
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 1
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  Coordinate projections, force-directed graphs
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    BI Platforms
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 1
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  Tableau Desktop/Server, PowerBI, Looker
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Geospatial Telemetry
                  </span>
                  <span className="font-mono text-[10px] text-gray-400 bg-white/5 px-1.5 py-0.5 border border-white/10 font-bold">
                    TIER 2
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  Deck.gl, Kepler.gl, GeoPandas
                </span>
              </div>

              <div className="p-2.5 bg-black/40 border border-white/10 flex flex-col">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-[#F5F5F5] font-semibold">
                    Scientific Notebooks
                  </span>
                  <span className="font-mono text-[10px] text-white bg-white/10 px-1.5 py-0.5 border border-white/20 font-bold">
                    TIER 1
                  </span>
                </div>
                <span className="font-sans text-xs text-gray-400 mt-1">
                  Plotly, Seaborn, Quarto, Marimo
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Live Feature Pipeline Log / Terminal Viewer */}
        <div className="p-6 bg-white/5 border border-white/10 flex flex-col gap-3 font-mono text-xs">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-white/20 inline-block" />
              <span className="w-2.5 h-2.5 rounded-full bg-white/40 inline-block" />
              <span className="w-2.5 h-2.5 rounded-full bg-white inline-block" />
              <span className="text-[#F5F5F5] font-bold ml-2 tracking-wider">
                TERMINAL_RUNTIME_MONITOR // pipeline_health_check.py
              </span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-gray-400 text-[11px] tracking-wider">
                STATUS: <span className="text-[#a8ffd2] font-semibold">200 OK • 0 ERRORS</span>
              </span>
              <button
                onClick={triggerAudit}
                disabled={isAuditing}
                className="px-3 py-1 bg-white text-black font-mono text-[10px] font-bold tracking-[0.2em] uppercase hover:bg-neutral-200 transition-colors flex items-center gap-1.5"
              >
                <RefreshCw className={`w-3 h-3 ${isAuditing ? 'animate-spin' : ''}`} />
                <span>{isAuditing ? 'AUDITING...' : 'RUN AUDIT'}</span>
              </button>
            </div>
          </div>

          <div className="font-mono text-xs bg-black/60 p-4 border border-white/10 flex flex-col gap-2 overflow-x-auto">
            {logs.map((log, index) => (
              <div key={index} className="text-gray-400 flex items-start gap-2 whitespace-nowrap">
                <span className="text-gray-500">[{log.timestamp}]</span>
                <span
                  className={
                    log.level === 'SUCCESS'
                      ? 'text-[#a8ffd2] font-bold'
                      : log.level === 'BENCH'
                      ? 'text-white font-bold'
                      : log.level === 'OUTPUT'
                      ? 'text-[#00daf3] font-bold'
                      : 'text-gray-300'
                  }
                >
                  {log.level}
                </span>
                <span className="text-[#F5F5F5]">{log.message}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
