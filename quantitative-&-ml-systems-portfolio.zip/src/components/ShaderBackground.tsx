import React, { useEffect, useRef } from 'react';

export const ShaderBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const gl =
      canvas.getContext('webgl') ||
      (canvas.getContext('experimental-webgl') as WebGLRenderingContext | null);

    if (!gl) return;

    let animationFrameId: number;
    let isDestroyed = false;

    const vsSource = `
      attribute vec2 a_position;
      varying vec2 v_texCoord;
      void main() {
        v_texCoord = a_position * 0.5 + 0.5;
        gl_Position = vec4(a_position, 0.0, 1.0);
      }
    `;

    const fsSource = `
      precision highp float;
      uniform float u_time;
      uniform vec2 u_resolution;
      uniform vec2 u_mouse;
      varying vec2 v_texCoord;

      float hash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
      }

      float noise(vec2 p) {
        vec2 i = floor(p);
        vec2 f = fract(p);
        vec2 u = f*f*(3.0-2.0*f);
        return mix(mix(hash(i + vec2(0.0,0.0)), hash(i + vec2(1.0,0.0)), u.x),
                   mix(hash(i + vec2(0.0,1.0)), hash(i + vec2(1.0,1.0)), u.x), u.y);
      }

      void main() {
        vec2 uv = gl_FragCoord.xy / u_resolution.xy;
        vec2 st = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
        
        vec2 mouseSt = (u_mouse - 0.5 * u_resolution.xy) / u_resolution.y;
        float distMouse = length(st - mouseSt);

        vec3 baseBg = vec3(0.039, 0.051, 0.082); // #0a0d15
        vec3 darkSurface = vec3(0.06, 0.08, 0.13); // #0f1421
        
        float t = u_time * 0.22;
        vec2 gridUV = st * 6.0;
        gridUV.y += sin(gridUV.x * 0.5 + t) * 0.35;
        gridUV.x += cos(gridUV.y * 0.5 + t * 0.8) * 0.25;
        
        vec2 gridLines = abs(fract(gridUV - 0.5) - 0.5);
        float line = min(gridLines.x, gridLines.y) * 16.0;
        float gridAlpha = clamp(1.0 - line, 0.0, 1.0);
        gridAlpha *= smoothstep(1.5, 0.2, length(st));
        
        // Wave flow
        float wave1 = sin(st.x * 4.0 + t * 1.5) * 0.15;
        float wave2 = cos(st.x * 8.0 - t * 1.2) * 0.08;
        float waveDist = abs(st.y - (wave1 + wave2) - 0.05);
        float waveGlow = exp(-waveDist * 18.0) * 0.65;
        
        float waveDist2 = abs(st.y - (wave1 * 1.5 - wave2 * 0.5) + 0.15);
        float waveGlow2 = exp(-waveDist2 * 25.0) * 0.4;
        
        vec2 nodeCoord = floor(st * 12.0);
        float nodeRand = hash(nodeCoord);
        float nodeIntensity = 0.0;
        if (nodeRand > 0.88) {
          vec2 nodeLocal = fract(st * 12.0) - 0.5;
          float d = length(nodeLocal);
          float pulse = sin(u_time * 2.0 + nodeRand * 6.28) * 0.5 + 0.5;
          nodeIntensity = smoothstep(0.12, 0.02, d) * pulse * 0.7;
        }
        
        vec3 cyan = vec3(0.0, 0.898, 1.0);
        vec3 emerald = vec3(0.063, 0.725, 0.506);
        vec3 violet = vec3(0.388, 0.278, 1.0);
        
        vec3 color = mix(baseBg, darkSurface, uv.y * 0.8);
        color += vec3(0.05, 0.15, 0.25) * gridAlpha * 0.55;
        color += mix(cyan, violet, uv.x) * waveGlow;
        color += mix(emerald, cyan, uv.y) * waveGlow2;
        color += cyan * nodeIntensity;
        
        float mouseGlow = exp(-distMouse * 4.0) * 0.22;
        color += cyan * mouseGlow;

        gl_FragColor = vec4(color, 1.0);
      }
    `;

    function compileShader(type: number, src: string) {
      const shader = gl!.createShader(type);
      if (!shader) return null;
      gl!.shaderSource(shader, src);
      gl!.compileShader(shader);
      if (!gl!.getShaderParameter(shader, gl!.COMPILE_STATUS)) {
        console.warn('Shader compile error:', gl!.getShaderInfoLog(shader));
        gl!.deleteShader(shader);
        return null;
      }
      return shader;
    }

    const vs = compileShader(gl.VERTEX_SHADER, vsSource);
    const fs = compileShader(gl.FRAGMENT_SHADER, fsSource);
    if (!vs || !fs) return;

    const program = gl.createProgram();
    if (!program) return;
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);

    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      console.warn('Program link error:', gl.getProgramInfoLog(program));
      return;
    }

    gl.useProgram(program);

    const buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(
      gl.ARRAY_BUFFER,
      new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]),
      gl.STATIC_DRAW
    );

    const pos = gl.getAttribLocation(program, 'a_position');
    gl.enableVertexAttribArray(pos);
    gl.vertexAttribPointer(pos, 2, gl.FLOAT, false, 0, 0);

    const uTime = gl.getUniformLocation(program, 'u_time');
    const uRes = gl.getUniformLocation(program, 'u_resolution');
    const uMouse = gl.getUniformLocation(program, 'u_mouse');

    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;

    const handleMouseMove = (e: MouseEvent) => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      if (rect.width && rect.height) {
        const nx = (e.clientX - rect.left) / rect.width;
        const ny = 1.0 - (e.clientY - rect.top) / rect.height;
        mouseX = nx * canvas.width;
        mouseY = ny * canvas.height;
      }
    };

    window.addEventListener('mousemove', handleMouseMove);

    const resize = () => {
      if (!canvas) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      const width = canvas.clientWidth || window.innerWidth;
      const height = canvas.clientHeight || 700;
      if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
        canvas.width = width * dpr;
        canvas.height = height * dpr;
      }
    };

    resize();
    const resizeObserver = new ResizeObserver(() => resize());
    resizeObserver.observe(canvas);

    const render = (time: number) => {
      if (isDestroyed) return;
      resize();
      gl.viewport(0, 0, canvas.width, canvas.height);

      if (uTime) gl.uniform1f(uTime, time * 0.001);
      if (uRes) gl.uniform2f(uRes, canvas.width, canvas.height);
      if (uMouse) gl.uniform2f(uMouse, mouseX, mouseY);

      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      isDestroyed = true;
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
    };
  }, []);

  return (
    <div className="absolute inset-0 w-full h-full opacity-45 pointer-events-none overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};
