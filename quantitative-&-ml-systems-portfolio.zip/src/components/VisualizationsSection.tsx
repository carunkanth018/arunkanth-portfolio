import React, { useState, useMemo } from 'react';
import { Play, RotateCcw, Activity, Layers, Sliders } from 'lucide-react';

export const VisualizationsSection: React.FC = () => {
  // Experiment A: Monte Carlo Simulation
  const [volatility, setVolatility] = useState(0.22);
  const [drift, setDrift] = useState(0.08);
  const [simRunId, setSimRunId] = useState(1);

  // Generate 8 representative stochastic paths
  const monteCarloPaths = useMemo(() => {
    const paths: string[] = [];
    const steps = 30;
    const width = 340;
    const height = 180;
    const startY = height / 2;

    for (let p = 0; p < 8; p++) {
      let currentY = startY;
      let pathD = `M 20 ${startY}`;
      for (let s = 1; s <= steps; s++) {
        const x = 20 + (s / steps) * (width - 40);
        // Deterministic pseudo-randomness based on seed and step
        const randomShock = (Math.sin(p * 17 + s * 31 + simRunId * 13) + Math.cos(s * 7 + p * 11)) * 0.5;
        const delta = (drift * 20 - randomShock * (volatility * 120)) * 0.6;
        currentY = Math.max(15, Math.min(height - 15, currentY - delta));
        pathD += ` L ${x.toFixed(1)} ${currentY.toFixed(1)}`;
      }
      paths.push(pathD);
    }
    return paths;
  }, [volatility, drift, simRunId]);

  const expectedTerminal = useMemo(() => {
    const base = 100 * Math.exp(drift + (volatility * 0.5));
    return base.toFixed(2);
  }, [volatility, drift]);

  // Experiment B: Manifold Projections (UMAP, t-SNE, PCA)
  const [projectionMethod, setProjectionMethod] = useState<'UMAP' | 't-SNE' | 'PCA'>('UMAP');
  const [activeCluster, setActiveCluster] = useState<number | null>(null);

  // Cluster coordinate definitions per projection
  const clusterData = useMemo(() => {
    if (projectionMethod === 'UMAP') {
      return [
        { id: 0, name: 'High-Freq Sensors', color: '#00daf3', count: 18, cx: 80, cy: 60, r: 35 },
        { id: 1, name: 'Cash Volatility', color: '#a8ffd2', count: 14, cx: 220, cy: 50, r: 30 },
        { id: 2, name: 'Baseline Equilibrium', color: '#89ceff', count: 22, cx: 160, cy: 130, r: 38 },
      ];
    } else if (projectionMethod === 't-SNE') {
      return [
        { id: 0, name: 'High-Freq Sensors', color: '#00daf3', count: 18, cx: 60, cy: 110, r: 32 },
        { id: 1, name: 'Cash Volatility', color: '#a8ffd2', count: 14, cx: 170, cy: 45, r: 28 },
        { id: 2, name: 'Baseline Equilibrium', color: '#89ceff', count: 22, cx: 240, cy: 125, r: 36 },
      ];
    } else {
      // PCA
      return [
        { id: 0, name: 'High-Freq Sensors', color: '#00daf3', count: 18, cx: 110, cy: 75, r: 42 },
        { id: 1, name: 'Cash Volatility', color: '#a8ffd2', count: 14, cx: 180, cy: 75, r: 35 },
        { id: 2, name: 'Baseline Equilibrium', color: '#89ceff', count: 22, cx: 220, cy: 105, r: 30 },
      ];
    }
  }, [projectionMethod]);

  return (
    <section id="visualizations" className="relative w-full py-20 md:py-28 bg-[#0A0A0A] border-b border-white/10 overflow-hidden">
      {/* Ghost Backdrop Typography Watermark */}
      <div className="absolute left-0 top-10 opacity-5 pointer-events-none select-none z-0">
        <span className="font-ghost-watermark text-[140px] sm:text-[220px] md:text-[300px] text-white tracking-tighter">
          SURFACE
        </span>
      </div>

      <div className="relative z-10 max-w-[1280px] mx-auto px-4 md:px-8 flex flex-col gap-12">
        {/* Section Title */}
        <div className="flex flex-col gap-3">
          <span className="font-mono text-[11px] text-gray-400 uppercase tracking-[0.3em] font-bold">
            04 // INTERACTIVE COMPUTATIONAL WORKBENCH
          </span>
          <h2 className="font-headline-lg text-[#F5F5F5] uppercase">
            Exploratory Data Surfaces &amp; Real-Time Projections
          </h2>
          <div className="h-[1px] w-24 bg-white/20 mt-1" />
          <p className="font-sans text-[0.9375rem] text-gray-400 max-w-3xl">
            Direct browser execution of stochastic simulations and coordinate embeddings. Experiment
            with live algorithmic parameters below.
          </p>
        </div>

        {/* Two Interactive Experiment Panels */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Experiment A: Monte Carlo Simulation */}
          <div className="p-6 bg-white/5 border border-white/10 flex flex-col gap-5 hover:border-white/30 transition-all">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-3">
                <span className="font-mono text-[10px] bg-white text-black px-2.5 py-0.5 font-bold uppercase tracking-[0.15em]">
                  EXPERIMENT A
                </span>
                <span className="font-mono text-xs text-gray-400 font-bold uppercase tracking-wider">
                  // STOCHASTIC_GEOMETRIC_BROWNIAN_MOTION
                </span>
              </div>
              <span className="font-mono text-[10px] text-white font-bold tracking-widest bg-white/10 px-2 py-0.5 border border-white/20">
                50 PATHS
              </span>
            </div>

            <p className="font-sans text-[0.875rem] text-gray-400">
              Simulate parallel asset paths with parameterizable drift (μ) and stochastic volatility
              shock vectors (σ).
            </p>

            {/* Interactive SVG Monte Carlo chart */}
            <div className="relative w-full h-52 bg-black/60 p-2 border border-white/10 flex items-center justify-center overflow-hidden">
              <svg className="w-full h-full" viewBox="0 0 340 180">
                {/* Horizontal reference bands */}
                <line x1="20" y1="45" x2="320" y2="45" stroke="rgba(255,255,255,0.08)" />
                <line x1="20" y1="90" x2="320" y2="90" stroke="rgba(255,255,255,0.2)" strokeDasharray="3 3" />
                <line x1="20" y1="135" x2="320" y2="135" stroke="rgba(255,255,255,0.08)" />

                {/* Trajectory lines */}
                {monteCarloPaths.map((d, idx) => {
                  const colors = ['#ffffff', '#a8ffd2', '#89ceff', '#e0e0e0', '#00daf3', '#ffffff'];
                  const strokeColor = colors[idx % colors.length];
                  return (
                    <path
                      key={idx}
                      d={d}
                      fill="none"
                      stroke={strokeColor}
                      strokeWidth="1.6"
                      opacity={idx === 0 ? 0.95 : 0.45}
                    />
                  );
                })}

                {/* Baseline origin marker */}
                <circle cx="20" cy="90" r="4" fill="#ffffff" />
                <text x="25" y="86" fill="#a3a3a3" fontFamily="JetBrains Mono" fontSize="8">
                  t_0 = $100
                </text>
              </svg>
            </div>

            {/* Readout statistics */}
            <div className="grid grid-cols-3 gap-2 font-mono text-xs">
              <div className="p-3 bg-black/40 border border-white/10">
                <span className="text-gray-400 text-[10px] block font-bold uppercase tracking-wider">EXP TERMINAL</span>
                <span className="text-white font-code-metric block text-base">${expectedTerminal}</span>
              </div>
              <div className="p-3 bg-black/40 border border-white/10">
                <span className="text-gray-400 text-[10px] block font-bold uppercase tracking-wider">VOLATILITY (σ)</span>
                <span className="text-white font-code-metric block text-base">{volatility.toFixed(2)}</span>
              </div>
              <div className="p-3 bg-black/40 border border-white/10">
                <span className="text-gray-400 text-[10px] block font-bold uppercase tracking-wider">DRIFT (μ)</span>
                <span className="text-[#a8ffd2] font-code-metric block text-base">{drift.toFixed(2)}</span>
              </div>
            </div>

            {/* Interactive Sliders */}
            <div className="flex flex-col gap-3 pt-1">
              <div className="flex items-center justify-between text-xs font-mono text-gray-300">
                <span>Volatility Shock (σ):</span>
                <input
                  type="range"
                  min="0.05"
                  max="0.45"
                  step="0.01"
                  value={volatility}
                  onChange={(e) => setVolatility(parseFloat(e.target.value))}
                  className="w-44 accent-white cursor-pointer"
                />
              </div>
              <div className="flex items-center justify-between text-xs font-mono text-gray-300">
                <span>Annual Drift (μ):</span>
                <input
                  type="range"
                  min="-0.15"
                  max="0.30"
                  step="0.01"
                  value={drift}
                  onChange={(e) => setDrift(parseFloat(e.target.value))}
                  className="w-44 accent-white cursor-pointer"
                />
              </div>
            </div>

            <button
              onClick={() => setSimRunId((prev) => prev + 1)}
              className="mt-1 w-full py-2.5 bg-white text-black font-mono text-xs font-bold uppercase tracking-[0.2em] flex items-center justify-center gap-2 hover:bg-neutral-200 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>RE-SAMPLE TRAJECTORIES</span>
            </button>
          </div>

          {/* Experiment B: Manifold Projections (UMAP, t-SNE, PCA) */}
          <div className="p-6 bg-white/5 border border-white/10 flex flex-col gap-5 hover:border-white/30 transition-all">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-3">
                <span className="font-mono text-[10px] bg-white text-black px-2.5 py-0.5 font-bold uppercase tracking-[0.15em]">
                  EXPERIMENT B
                </span>
                <span className="font-mono text-xs text-gray-400 font-bold uppercase tracking-wider">
                  // MANIFOLD_PROJECTION_SPACE
                </span>
              </div>
              <span className="font-mono text-[10px] text-white font-bold tracking-widest bg-white/10 px-2 py-0.5 border border-white/20">
                64D &rarr; 2D
              </span>
            </div>

            <p className="font-sans text-[0.875rem] text-gray-400">
              Synthetic 64-dimensional feature vector projected onto 2D Riemannian surface using
              probabilistic topology preserving techniques.
            </p>

            {/* Projection Selector Buttons */}
            <div className="flex items-center gap-2 font-mono text-xs">
              {(['UMAP', 't-SNE', 'PCA'] as const).map((method) => (
                <button
                  key={method}
                  onClick={() => setProjectionMethod(method)}
                  className={`flex-1 py-2 font-bold uppercase tracking-[0.15em] transition-all ${
                    projectionMethod === method
                      ? 'bg-white text-black'
                      : 'bg-black/40 text-gray-400 border border-white/10 hover:border-white/30 hover:text-white'
                  }`}
                >
                  {method}
                </button>
              ))}
            </div>

            {/* Interactive Scatter Canvas */}
            <div className="relative w-full h-52 bg-black/60 p-2 border border-white/10 flex items-center justify-center overflow-hidden">
              <svg className="w-full h-full" viewBox="0 0 300 180">
                {/* Cluster regions with glow */}
                {clusterData.map((cluster) => {
                  const isHovered = activeCluster === cluster.id;
                  return (
                    <g
                      key={cluster.id}
                      className="cursor-pointer transition-all duration-300"
                      onMouseEnter={() => setActiveCluster(cluster.id)}
                      onMouseLeave={() => setActiveCluster(null)}
                    >
                      {/* Cluster cloud boundary */}
                      <circle
                        cx={cluster.cx}
                        cy={cluster.cy}
                        r={cluster.r}
                        fill={cluster.color}
                        opacity={isHovered ? 0.25 : 0.12}
                        stroke={cluster.color}
                        strokeDasharray="2 2"
                        strokeWidth="1"
                      />

                      {/* Cluster Center */}
                      <circle cx={cluster.cx} cy={cluster.cy} r={5} fill={cluster.color} />
                      <circle
                        cx={cluster.cx}
                        cy={cluster.cy}
                        r={9}
                        fill="none"
                        stroke={cluster.color}
                        opacity={0.4}
                      />

                      {/* Cluster label */}
                      <text
                        x={cluster.cx}
                        y={cluster.cy - cluster.r - 4}
                        textAnchor="middle"
                        fill={cluster.color}
                        fontFamily="JetBrains Mono"
                        fontSize="8"
                        fontWeight="600"
                      >
                        {cluster.name}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>

            {/* Readout stats */}
            <div className="grid grid-cols-3 gap-2 font-mono text-xs">
              <div className="p-3 bg-black/40 border border-white/10">
                <span className="text-gray-400 text-[10px] block font-bold uppercase tracking-wider">MANIFOLD EMBEDDING</span>
                <span className="text-white font-code-metric block text-base">{projectionMethod}</span>
              </div>
              <div className="p-3 bg-black/40 border border-white/10">
                <span className="text-gray-400 text-[10px] block font-bold uppercase tracking-wider">SILHOUETTE SCORE</span>
                <span className="text-[#a8ffd2] font-code-metric block text-base">
                  {projectionMethod === 'UMAP' ? '0.884' : projectionMethod === 't-SNE' ? '0.861' : '0.712'}
                </span>
              </div>
              <div className="p-3 bg-black/40 border border-white/10">
                <span className="text-gray-400 text-[10px] block font-bold uppercase tracking-wider">VARIANCE EXPLAINED</span>
                <span className="text-white font-code-metric block text-base">
                  {projectionMethod === 'PCA' ? '74.8%' : 'Preserved Topo'}
                </span>
              </div>
            </div>

            {/* Quick legend */}
            <div className="flex items-center justify-between text-xs font-mono text-gray-400 pt-1">
              <span>PROJECTION: {projectionMethod} (CONVERGED)</span>
              <span className="text-[#a8ffd2] font-bold">HOVER TO INSPECT</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
