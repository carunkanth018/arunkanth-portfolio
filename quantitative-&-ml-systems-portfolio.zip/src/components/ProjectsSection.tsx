import React, { useState } from 'react';
import { ProjectModal } from './ProjectModal';
import { CaseStudy } from '../types';

export const ProjectsSection: React.FC = () => {
  // Modal state
  const [activeModalStudy, setActiveModalStudy] = useState<CaseStudy | null>(null);
  const [modalMode, setModalMode] = useState<'architecture' | 'repo' | 'notebook' | 'whitepaper'>('architecture');

  // Case Study 01 State (Scatter drift simulation)
  const [thresholdY, setThresholdY] = useState(50);
  const [anomalyScoreText, setAnomalyScoreText] = useState('SCORE: 0.142 (NORMAL)');
  const [isAlert, setIsAlert] = useState(false);
  const [isSimulatingDrift, setIsSimulatingDrift] = useState(false);

  // Case Study 03 Node inspection state
  const [activeDagNode, setActiveDagNode] = useState<string | null>('FCT_KPI');

  const caseStudies: CaseStudy[] = [
    {
      id: 'anomaly',
      number: 'CASE STUDY 01',
      tag: 'STREAMING_ANOMALY_ENGINE',
      title: 'Multi-Variate Telemetry Anomaly Detection Engine',
      dataset: 'DATASET: 1.2B SYNTHETIC LOG EVENTS',
      status: 'DEPLOYED IN PROD',
      summary:
        'High-throughput streaming sensor infrastructure suffers from sudden drift and covariate shifts that break rule-based alerts. Built a semi-supervised autoencoder combined with an ensemble Isolation Forest layer, calculating dynamic Mahalanobis distances over rolling entropy windows to eliminate baseline false positives.',
      metrics: [
        { label: 'FALSE POSITIVES', value: '-74.2%', subtext: 'vs threshold alerts', color: 'primary' },
        { label: 'TRUE POSITIVE RECALL', value: '99.2%', subtext: 'Critical drift caught', color: 'tertiary' },
        { label: 'DOWNTIME PREVENTED', value: '$1.4M', subtext: 'Annualized savings', color: 'secondary' },
      ],
      specDetails: {
        architecture: [
          'Dual-stage pipeline: deep autoencoder dimensionality compression + Mahalanobis distance metric',
          'Rolling sliding-window entropy calculation across 128 sensor channel telemetry streams',
          'Real-time inference server deployed on Triton with ONNX dynamic batch execution',
          'Sub-15ms end-to-end alert triggering directly into PagerDuty & Slack webhooks',
        ],
        techStack: ['PyTorch', 'ONNX Runtime', 'Kafka', 'Rust Ingestion Daemon', 'Triton Server'],
        outcomes: [
          'Zero unacknowledged anomalies over 12 consecutive months of 24/7 continuous operation',
          'Cut alert volume by 74.2%, allowing SRE teams to maintain 99.99% availability SLAs',
        ],
        codeSnippet: `class AnomalyAutoencoder(nn.Module):
    def __init__(self, input_dim=128, latent_dim=16):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.LayerNorm(64),
            nn.SiLU(),
            nn.Linear(64, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 64),
            nn.SiLU(),
            nn.Linear(64, input_dim)
        )
    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z), z`,
      },
    },
    {
      id: 'bayesian',
      number: 'CASE STUDY 02',
      tag: 'BAYESIAN_CAUSAL_ATTRIBUTION',
      title: 'Bayesian Marketing Mix & Multi-Channel Causal Attribution',
      dataset: 'METHOD: HIERARCHICAL MCMC IN STAN & PYMC',
      status: 'AUDITED & VALIDATED',
      summary:
        'Last-touch attribution models fail to capture multi-channel lag effects, diminishing marginal returns (Hill functions), and organic brand baseline equity. Engineered a hierarchical Bayesian regression framework incorporating Markov Chain Monte Carlo (MCMC) posterior sampling to calculate true incremental lift across $80M in distributed media spend.',
      metrics: [
        { label: 'BUDGET EFFICIENCY', value: '+32.4%', subtext: 'ROAS reallocated', color: 'secondary' },
        { label: 'CANNIBALIZATION', value: '$850k', subtext: 'Paid search waste cut', color: 'primary' },
        { label: 'POSTERIOR CREDIBILITY', value: '95% CI', subtext: 'Full uncertainty band', color: 'tertiary' },
      ],
      specDetails: {
        architecture: [
          'Hierarchical Bayesian parameter priors with half-normal distribution on channel elasticity',
          'Adstock decay modeling geometric carryover + Weibull lag curves per media channel',
          'Ad-hoc synthetic control group validation benchmarked against geographic split-testing',
          'Continuous posterior sampling with 4 parallel MCMC chains across 2,000 draws',
        ],
        techStack: ['PyMC', 'Stan', 'ArviZ', 'Snowflake SQL', 'Streamlit Executive App'],
        outcomes: [
          'Uncovered $850k cannibalization in brand search where organic search had 94% substitution',
          'Shifted $6.2M into high-elasticity digital audio and programmatic display',
        ],
        codeSnippet: `with pm.Model() as mmm_model:
    alpha = pm.HalfNormal("alpha", sigma=5)
    adstock = pm.Beta("retention", alpha=3, beta=3)
    # Hill saturation function
    K = pm.HalfNormal("half_sat", sigma=spend_mean)
    S = spend_adstocked / (spend_adstocked + K)
    y_obs = pm.Normal("y_obs", mu=alpha + pm.math.dot(S, beta), sigma=sigma, observed=revenue)`,
      },
    },
    {
      id: 'lakehouse',
      number: 'CASE STUDY 03',
      tag: 'LAKEHOUSE_SEMANTIC_LAYER',
      title: 'Distributed Enterprise Semantic Layer & Lakehouse Migration',
      dataset: 'PLATFORMS: ICEBERG • TRINO • DBT CORE',
      status: 'PRODUCTION INFRASTRUCTURE',
      summary:
        'Replaced legacy fragmented data warehouses and manual ad-hoc SQL reporting with a modern lakehouse architecture. Standardized over 400 analytical metrics in dbt Semantic Layer on Apache Iceberg, queryable across Starburst Trino and downstream BI applications with sub-second latency.',
      metrics: [
        { label: 'P95 QUERY TIME', value: '680ms', subtext: 'Down from 42s', color: 'tertiary' },
        { label: 'METRIC DISCREPANCY', value: '0.0%', subtext: 'Single source of truth', color: 'primary' },
        { label: 'COMPUTE COST REDUCTION', value: '-58%', subtext: 'Via predicate pushdown', color: 'secondary' },
      ],
      specDetails: {
        architecture: [
          'Apache Iceberg v2 open table format with Z-order clustering on temporal & entity keys',
          'dbt MetricFlow semantic specification enforcing immutable metric calculations company-wide',
          'Trino distributed SQL query cluster utilizing dynamic query pushdown into S3 parquet files',
          'Airflow DAG orchestration with automated data contract enforcement and Great Expectations',
        ],
        techStack: ['Apache Iceberg', 'Starburst Trino', 'dbt Core', 'Apache Airflow', 'AWS S3'],
        outcomes: [
          'Eliminated conflicting board metrics across finance, product, and growth teams',
          'P95 dashboard rendering latency dropped from 42s to 680ms, saving $380k in compute',
        ],
        codeSnippet: `metrics:
  - name: recurring_gross_retention
    label: "Recurring Gross Retention (GRR)"
    type: ratio
    type_params:
      numerator: retained_arr_usd
      denominator: starting_arr_usd
    filter: |
      customer_tier in ('Enterprise', 'Strategic')`,
      },
    },
  ];

  const handleSliderChange = (val: number) => {
    setThresholdY(val);
    if (val < 40) {
      setAnomalyScoreText('SCORE: 0.884 (CRITICAL ALERT TRIGGERED)');
      setIsAlert(true);
    } else {
      setAnomalyScoreText('SCORE: 0.142 (NORMAL)');
      setIsAlert(false);
    }
  };

  const handleSimulateDrift = () => {
    setIsSimulatingDrift(true);
    setAnomalyScoreText('DRIFT DETECTED: ENTROPY ANOMALY (p < 0.001)');
    setIsAlert(true);
    setTimeout(() => {
      setIsSimulatingDrift(false);
      setAnomalyScoreText('SCORE: 0.142 (NORMAL)');
      setIsAlert(false);
    }, 3500);
  };

  const openModal = (study: CaseStudy, mode: 'architecture' | 'repo' | 'notebook' | 'whitepaper') => {
    setActiveModalStudy(study);
    setModalMode(mode);
  };

  return (
    <section id="projects" className="relative w-full py-20 md:py-28 bg-[#0A0A0A] border-b border-white/10 overflow-hidden">
      {/* Ghost Backdrop Typography Watermark */}
      <div className="absolute right-0 top-12 opacity-5 pointer-events-none select-none z-0">
        <span className="font-ghost-watermark text-[140px] sm:text-[220px] md:text-[320px] text-white tracking-tighter">
          IMPACT
        </span>
      </div>

      <div className="relative z-10 max-w-[1280px] mx-auto px-4 md:px-8 flex flex-col gap-12">
        {/* Section Header */}
        <div className="flex flex-col gap-3">
          <span className="font-mono text-[11px] text-gray-400 uppercase tracking-[0.3em] font-bold">
            03 // PRODUCTION CASE STUDIES &amp; ARCHITECTURES
          </span>
          <h2 className="font-headline-lg text-[#F5F5F5] uppercase">
            Empirical Case Studies &amp; High-Throughput Systems
          </h2>
          <div className="h-[1px] w-24 bg-white/20 mt-1" />
          <p className="font-sans text-[0.9375rem] text-gray-400 max-w-3xl">
            Architectural deep-dives across streaming anomaly detection, causal attribution, and
            unified distributed data lakehouse platforms.
          </p>
        </div>

        {/* Case Study 01: Multi-Variate Telemetry Anomaly Detection */}
        <div className="p-6 md:p-8 bg-white/5 border border-white/10 flex flex-col gap-6 hover:border-white/30 transition-all">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-0.5 bg-white text-black font-mono text-[10px] font-bold tracking-[0.15em] uppercase">
                CASE STUDY 01
              </span>
              <span className="font-mono text-xs tracking-[0.2em] text-gray-400 font-bold uppercase">
                // STREAMING_ANOMALY_ENGINE
              </span>
            </div>
            <div className="flex items-center gap-2 font-mono text-[10px] tracking-wider text-gray-400">
              <span>DATASET: 1.2B SYNTHETIC LOG EVENTS</span>
              <span>&bull;</span>
              <span className="text-[#a8ffd2] font-bold">DEPLOYED IN PROD</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Text Content (7 cols) */}
            <div className="lg:col-span-7 flex flex-col gap-4">
              <h3 className="font-headline-md text-[#F5F5F5]">
                Multi-Variate Telemetry Anomaly Detection Engine
              </h3>
              <p className="font-sans text-[0.9375rem] text-gray-400 leading-relaxed border-l-2 border-white/10 pl-4">
                High-throughput streaming sensor infrastructure suffers from sudden drift and
                covariate shifts that break rule-based alerts. Built a semi-supervised autoencoder
                combined with an ensemble Isolation Forest layer, calculating dynamic Mahalanobis
                distances over rolling entropy windows to eliminate baseline false positives.
              </p>

              {/* Key Results Strip */}
              <div className="grid grid-cols-3 gap-3 pt-2">
                <div className="p-3 bg-black/40 border border-white/10">
                  <span className="font-mono text-[10px] text-gray-400 block tracking-wider uppercase font-bold">
                    FALSE POSITIVES
                  </span>
                  <span className="font-code-metric text-[#F5F5F5] block">-74.2%</span>
                  <span className="font-mono text-[10px] text-gray-400">vs threshold alerts</span>
                </div>
                <div className="p-3 bg-black/40 border border-white/10">
                  <span className="font-mono text-[10px] text-gray-400 block tracking-wider uppercase font-bold">
                    TRUE POSITIVE RECALL
                  </span>
                  <span className="font-code-metric text-[#a8ffd2] block">99.2%</span>
                  <span className="font-mono text-[10px] text-gray-400">Critical drift caught</span>
                </div>
                <div className="p-3 bg-black/40 border border-white/10">
                  <span className="font-mono text-[10px] text-gray-400 block tracking-wider uppercase font-bold">
                    DOWNTIME PREVENTED
                  </span>
                  <span className="font-code-metric text-[#F5F5F5] block">$1.4M</span>
                  <span className="font-mono text-[10px] text-gray-400">Annualized savings</span>
                </div>
              </div>

              {/* Action Links */}
              <div className="flex flex-wrap items-center gap-3 pt-2 font-mono text-xs">
                <button
                  onClick={() => openModal(caseStudies[0], 'architecture')}
                  className="px-4 py-2 bg-white text-black font-bold uppercase tracking-[0.15em] hover:bg-neutral-200 transition-all"
                >
                  [ ARCHITECTURE SPEC ]
                </button>
                <button
                  onClick={() => openModal(caseStudies[0], 'repo')}
                  className="px-4 py-2 bg-white/5 text-white hover:bg-white/10 border border-white/20 uppercase tracking-[0.15em] transition-colors"
                >
                  [ REPOSITORY ]
                </button>
                <button
                  onClick={() => openModal(caseStudies[0], 'notebook')}
                  className="px-4 py-2 bg-white/5 text-[#a8ffd2] hover:bg-[#a8ffd2]/20 border border-[#a8ffd2]/30 uppercase tracking-[0.15em] transition-all"
                >
                  [ SIMULATOR NOTEBOOK ]
                </button>
              </div>
            </div>

            {/* Interactive Mini-Visualizer (5 cols) */}
            <div className="lg:col-span-5 p-4 bg-black/60 border border-white/10 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] text-gray-400 uppercase tracking-[0.2em] font-bold">
                  LIVE ANOMALY SCATTER DRIFT
                </span>
                <span
                  className={`font-mono text-xs font-bold ${
                    isAlert ? 'text-[#ffb4ab]' : 'text-white'
                  }`}
                >
                  {anomalyScoreText}
                </span>
              </div>

              {/* Dynamic SVG Scatter Simulation */}
              <div className="relative w-full h-48 bg-black/40 flex items-center justify-center overflow-hidden border border-white/10">
                <svg className="w-full h-full" viewBox="0 0 320 160">
                  {/* Grid Lines */}
                  <line x1="20" y1="20" x2="300" y2="20" stroke="rgba(255,255,255,0.08)" />
                  <line x1="20" y1="60" x2="300" y2="60" stroke="rgba(255,255,255,0.08)" />
                  <line x1="20" y1="100" x2="300" y2="100" stroke="rgba(255,255,255,0.08)" />
                  <line x1="20" y1="140" x2="300" y2="140" stroke="rgba(255,255,255,0.08)" />

                  {/* Dynamic Threshold Line */}
                  <line
                    x1="20"
                    y1={thresholdY}
                    x2="300"
                    y2={thresholdY}
                    stroke="#ffffff"
                    strokeDasharray="4 4"
                    strokeWidth="1.5"
                  />
                  <text x="25" y={Math.max(14, thresholdY - 6)} fill="#ffffff" fontFamily="JetBrains Mono" fontSize="9">
                    ALERT THRESHOLD ({thresholdY}px)
                  </text>

                  {/* Scatter Normal Points */}
                  <g>
                    <circle cx="45" cy="110" r="3" fill="#ffffff" opacity="0.8" />
                    <circle cx="70" cy="95" r="3" fill="#ffffff" opacity="0.7" />
                    <circle cx="95" cy="120" r="3" fill="#ffffff" opacity="0.9" />
                    <circle cx="120" cy="85" r="3" fill="#ffffff" opacity="0.6" />
                    <circle cx="145" cy="105" r="3" fill="#ffffff" opacity="0.8" />
                    <circle cx="170" cy="90" r="3" fill="#ffffff" opacity="0.8" />
                    <circle cx="195" cy="115" r="3" fill="#ffffff" opacity="0.7" />
                    <circle cx="220" cy="80" r="3" fill="#ffffff" opacity="0.8" />
                    <circle cx="245" cy="100" r="3" fill="#ffffff" opacity="0.9" />
                    <circle cx="270" cy="95" r="3" fill="#ffffff" opacity="0.7" />
                  </g>

                  {/* Scatter Anomaly Points */}
                  <g>
                    <circle cx="210" cy="35" r="4.5" fill="#a8ffd2" />
                    <circle cx="210" cy="35" r="8" fill="#a8ffd2" opacity="0.3" className="animate-ping" />
                    <circle cx="280" cy="28" r="4.5" fill="#a8ffd2" />
                    {isSimulatingDrift && (
                      <>
                        <circle cx="160" cy="25" r="5" fill="#ffb4ab" />
                        <circle cx="180" cy="18" r="4.5" fill="#ffb4ab" />
                        <circle cx="160" cy="25" r="10" fill="#ffb4ab" opacity="0.4" className="animate-ping" />
                      </>
                    )}
                  </g>
                </svg>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-between gap-3 pt-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[10px] text-gray-400">SENSITIVITY:</span>
                  <input
                    type="range"
                    min="20"
                    max="120"
                    value={thresholdY}
                    onChange={(e) => handleSliderChange(Number(e.target.value))}
                    className="w-24 accent-white cursor-pointer"
                  />
                </div>
                <button
                  onClick={handleSimulateDrift}
                  disabled={isSimulatingDrift}
                  className="px-3 py-1 bg-white/10 hover:bg-white hover:text-black text-white font-mono text-[10px] font-bold tracking-wider border border-white/20 transition-colors uppercase"
                >
                  {isSimulatingDrift ? 'DRIFT ACTIVE...' : 'SIMULATE DRIFT'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Case Study 02: Bayesian Marketing Mix */}
        <div className="p-6 md:p-8 bg-white/5 border border-white/10 flex flex-col gap-6 hover:border-white/30 transition-all">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-0.5 bg-white text-black font-mono text-[10px] font-bold tracking-[0.15em] uppercase">
                CASE STUDY 02
              </span>
              <span className="font-mono text-xs tracking-[0.2em] text-gray-400 font-bold uppercase">
                // BAYESIAN_CAUSAL_ATTRIBUTION
              </span>
            </div>
            <div className="flex items-center gap-2 font-mono text-[10px] tracking-wider text-gray-400">
              <span>METHOD: HIERARCHICAL MCMC IN STAN &amp; PYMC</span>
              <span>&bull;</span>
              <span className="text-white font-bold">AUDITED &amp; VALIDATED</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Text Content (7 cols) */}
            <div className="lg:col-span-7 flex flex-col gap-4">
              <h3 className="font-headline-md text-[#F5F5F5]">
                Bayesian Marketing Mix &amp; Multi-Channel Causal Attribution
              </h3>
              <p className="font-sans text-[0.9375rem] text-gray-400 leading-relaxed border-l-2 border-white/10 pl-4">
                Last-touch attribution models fail to capture multi-channel lag effects, diminishing
                marginal returns (Hill functions), and organic brand baseline equity. Engineered a
                hierarchical Bayesian regression framework incorporating Markov Chain Monte Carlo
                (MCMC) posterior sampling to calculate true incremental lift across $80M in
                distributed media spend.
              </p>

              {/* Key Results Strip */}
              <div className="grid grid-cols-3 gap-3 pt-2">
                <div className="p-3 bg-black/40 border border-white/10">
                  <span className="font-mono text-[10px] text-gray-400 block tracking-wider uppercase font-bold">
                    BUDGET EFFICIENCY
                  </span>
                  <span className="font-code-metric text-[#F5F5F5] block">+32.4%</span>
                  <span className="font-mono text-[10px] text-gray-400">ROAS reallocated</span>
                </div>
                <div className="p-3 bg-black/40 border border-white/10">
                  <span className="font-mono text-[10px] text-gray-400 block tracking-wider uppercase font-bold">
                    CANNIBALIZATION
                  </span>
                  <span className="font-code-metric text-[#a8ffd2] block">$850k</span>
                  <span className="font-mono text-[10px] text-gray-400">Paid search waste cut</span>
                </div>
                <div className="p-3 bg-black/40 border border-white/10">
                  <span className="font-mono text-[10px] text-gray-400 block tracking-wider uppercase font-bold">
                    POSTERIOR CREDIBILITY
                  </span>
                  <span className="font-code-metric text-[#F5F5F5] block">95% CI</span>
                  <span className="font-mono text-[10px] text-gray-400">Full uncertainty band</span>
                </div>
              </div>

              {/* Action Links */}
              <div className="flex flex-wrap items-center gap-3 pt-2 font-mono text-xs">
                <button
                  onClick={() => openModal(caseStudies[1], 'whitepaper')}
                  className="px-4 py-2 bg-white text-black font-bold uppercase tracking-[0.15em] hover:bg-neutral-200 transition-all"
                >
                  [ METHODOLOGY WHITEPAPER ]
                </button>
                <button
                  onClick={() => openModal(caseStudies[1], 'architecture')}
                  className="px-4 py-2 bg-white/5 text-white hover:bg-white/10 border border-white/20 uppercase tracking-[0.15em] transition-colors"
                >
                  [ POSTERIOR PROJECTION CODE ]
                </button>
              </div>
            </div>

            {/* Posterior Density Curve Visualization (5 cols) */}
            <div className="lg:col-span-5 p-4 bg-black/60 border border-white/10 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] text-gray-400 uppercase tracking-[0.2em] font-bold">
                  POSTERIOR DISTRIBUTIONS (MCMC)
                </span>
                <span className="font-mono text-xs text-white font-bold">
                  HDI: [1.34, 2.11]
                </span>
              </div>
              <div className="relative w-full h-48 bg-black/40 flex items-center justify-center p-2 border border-white/10">
                <svg className="w-full h-full" viewBox="0 0 300 150">
                  {/* Density Bell Curve 1 (Organic baseline) */}
                  <path
                    d="M 20 140 C 60 140, 70 80, 100 40 C 130 80, 140 140, 180 140 Z"
                    fill="rgba(255, 255, 255, 0.1)"
                    stroke="#ffffff"
                    strokeWidth="1.5"
                  />
                  <text x="75" y="32" fill="#ffffff" fontFamily="JetBrains Mono" fontSize="9">
                    ORGANIC PRIORS
                  </text>

                  {/* Density Bell Curve 2 (Paid Lift with CI fill) */}
                  <path
                    d="M 120 140 C 160 140, 180 30, 210 20 C 240 30, 260 140, 290 140 Z"
                    fill="rgba(255, 255, 255, 0.2)"
                    stroke="#ffffff"
                    strokeWidth="2"
                  />
                  <text x="180" y="15" fill="#a8ffd2" fontFamily="JetBrains Mono" fontSize="9">
                    ESTIMATED LIFT
                  </text>

                  {/* Credible Interval Marker */}
                  <line x1="170" y1="135" x2="250" y2="135" stroke="#a8ffd2" strokeWidth="3" />
                  <circle cx="210" cy="135" r="4" fill="#a8ffd2" />
                  <text x="175" y="125" fill="#a8ffd2" fontFamily="JetBrains Mono" fontSize="8">
                    95% CREDIBLE INTERVAL
                  </text>
                </svg>
              </div>
              <div className="flex items-center justify-between font-mono text-[10px] text-gray-400">
                <span>SAMPLES: 4 CHAINS x 2,000 DRAWS</span>
                <span className="text-[#a8ffd2] font-bold">R-HAT: 1.002 (CONVERGED)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Case Study 03: Lakehouse Migration */}
        <div className="p-6 md:p-8 bg-white/5 border border-white/10 flex flex-col gap-6 hover:border-white/30 transition-all">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-0.5 bg-white text-black font-mono text-[10px] font-bold tracking-[0.15em] uppercase">
                CASE STUDY 03
              </span>
              <span className="font-mono text-xs tracking-[0.2em] text-gray-400 font-bold uppercase">
                // LAKEHOUSE_SEMANTIC_LAYER
              </span>
            </div>
            <div className="flex items-center gap-2 font-mono text-[10px] tracking-wider text-gray-400">
              <span>PLATFORMS: ICEBERG &bull; TRINO &bull; DBT CORE</span>
              <span>&bull;</span>
              <span className="text-[#a8ffd2] font-bold">PRODUCTION INFRASTRUCTURE</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Text Content (7 cols) */}
            <div className="lg:col-span-7 flex flex-col gap-4">
              <h3 className="font-headline-md text-[#F5F5F5]">
                Distributed Enterprise Semantic Layer &amp; Lakehouse Migration
              </h3>
              <p className="font-sans text-[0.9375rem] text-gray-400 leading-relaxed border-l-2 border-white/10 pl-4">
                Replaced legacy fragmented data warehouses and manual ad-hoc SQL reporting with a
                modern lakehouse architecture. Standardized over 400 analytical metrics in dbt
                Semantic Layer on Apache Iceberg, queryable across Starburst Trino and downstream BI
                applications with sub-second latency.
              </p>

              {/* Key Results Strip */}
              <div className="grid grid-cols-3 gap-3 pt-2">
                <div className="p-3 bg-black/40 border border-white/10">
                  <span className="font-mono text-[10px] text-gray-400 block tracking-wider uppercase font-bold">
                    P95 QUERY TIME
                  </span>
                  <span className="font-code-metric text-[#a8ffd2] block">680ms</span>
                  <span className="font-mono text-[10px] text-gray-400">Down from 42s</span>
                </div>
                <div className="p-3 bg-black/40 border border-white/10">
                  <span className="font-mono text-[10px] text-gray-400 block tracking-wider uppercase font-bold">
                    METRIC DISCREPANCY
                  </span>
                  <span className="font-code-metric text-[#F5F5F5] block">0.0%</span>
                  <span className="font-mono text-[10px] text-gray-400">Single source of truth</span>
                </div>
                <div className="p-3 bg-black/40 border border-white/10">
                  <span className="font-mono text-[10px] text-gray-400 block tracking-wider uppercase font-bold">
                    COMPUTE COST REDUCTION
                  </span>
                  <span className="font-code-metric text-[#F5F5F5] block">-58%</span>
                  <span className="font-mono text-[10px] text-gray-400">Via predicate pushdown</span>
                </div>
              </div>

              {/* Action Links */}
              <div className="flex flex-wrap items-center gap-3 pt-2 font-mono text-xs">
                <button
                  onClick={() => openModal(caseStudies[2], 'architecture')}
                  className="px-4 py-2 bg-white text-black font-bold uppercase tracking-[0.15em] hover:bg-neutral-200 transition-all"
                >
                  [ ARCHITECTURAL BLUEPRINT ]
                </button>
                <button
                  onClick={() => openModal(caseStudies[2], 'repo')}
                  className="px-4 py-2 bg-white/5 text-white hover:bg-white/10 border border-white/20 uppercase tracking-[0.15em] transition-colors"
                >
                  [ DBT DAG REPO ]
                </button>
              </div>
            </div>

            {/* Lineage Graph Visualization (5 cols) */}
            <div className="lg:col-span-5 p-4 bg-black/60 border border-white/10 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] text-gray-400 uppercase tracking-[0.2em] font-bold">
                  DAG LINEAGE NODE MAP
                </span>
                <span className="font-mono text-xs text-[#a8ffd2] font-bold">
                  SELECTED: {activeDagNode}
                </span>
              </div>

              <div className="relative w-full h-48 bg-black/40 flex items-center justify-center p-3 border border-white/10">
                <svg className="w-full h-full" viewBox="0 0 320 160">
                  {/* Connective Lines */}
                  <path d="M 50 80 L 120 40" stroke="rgba(255,255,255,0.2)" strokeWidth="1.5" />
                  <path d="M 50 80 L 120 120" stroke="rgba(255,255,255,0.2)" strokeWidth="1.5" />
                  <path d="M 120 40 L 200 80" stroke="#ffffff" strokeWidth="2" />
                  <path d="M 120 120 L 200 80" stroke="#ffffff" strokeWidth="2" />
                  <path d="M 200 80 L 280 80" stroke="#a8ffd2" strokeWidth="2.5" />

                  {/* Nodes */}
                  {/* Raw Stage */}
                  <g
                    className="cursor-pointer"
                    onClick={() => setActiveDagNode('RAW_S3_DELTA')}
                  >
                    <circle cx="50" cy="80" r="14" fill="#171717" stroke="#737373" strokeWidth="2" />
                    <text x="38" y="84" fill="#f5f5f5" fontFamily="JetBrains Mono" fontSize="8">
                      RAW
                    </text>
                  </g>

                  {/* Stage Models */}
                  <g className="cursor-pointer" onClick={() => setActiveDagNode('STG_TELEMETRY')}>
                    <circle cx="120" cy="40" r="14" fill="#171717" stroke="#ffffff" strokeWidth="2" />
                    <text x="108" y="44" fill="#ffffff" fontFamily="JetBrains Mono" fontSize="8">
                      STG_A
                    </text>
                  </g>
                  <g className="cursor-pointer" onClick={() => setActiveDagNode('STG_FINANCIAL')}>
                    <circle cx="120" cy="120" r="14" fill="#171717" stroke="#ffffff" strokeWidth="2" />
                    <text x="108" y="124" fill="#ffffff" fontFamily="JetBrains Mono" fontSize="8">
                      STG_B
                    </text>
                  </g>

                  {/* Mart Node */}
                  <g className="cursor-pointer" onClick={() => setActiveDagNode('FCT_KPI')}>
                    <circle cx="200" cy="80" r="18" fill="#171717" stroke="#a8ffd2" strokeWidth="2" />
                    <circle
                      cx="200"
                      cy="80"
                      r="24"
                      fill="none"
                      stroke="#a8ffd2"
                      strokeWidth="1"
                      opacity="0.3"
                      className="animate-ping"
                    />
                    <text x="187" y="84" fill="#a8ffd2" fontFamily="JetBrains Mono" fontSize="8">
                      FCT_KPI
                    </text>
                  </g>

                  {/* Semantic Output */}
                  <g className="cursor-pointer" onClick={() => setActiveDagNode('TRINO_QUERY_LAYER')}>
                    <circle cx="280" cy="80" r="16" fill="#003824" stroke="#a8ffd2" strokeWidth="2" />
                    <text x="270" y="84" fill="#ffffff" fontFamily="JetBrains Mono" fontSize="8">
                      TRINO
                    </text>
                  </g>
                </svg>
              </div>

              <div className="flex items-center justify-between font-mono text-[10px] text-gray-400">
                <span>ORCHESTRATOR: AIRFLOW DAG_V3</span>
                <span className="text-[#a8ffd2] font-bold">LAST RUN: 4 MIN AGO (SUCCESS)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Specification Modal */}
      {activeModalStudy && (
        <ProjectModal
          study={activeModalStudy}
          mode={modalMode}
          onClose={() => setActiveModalStudy(null)}
        />
      )}
    </section>
  );
};
