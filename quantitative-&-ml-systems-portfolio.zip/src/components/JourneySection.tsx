import React from 'react';
import { BookOpen, Award, CheckCircle2 } from 'lucide-react';
import { CareerMilestone } from '../types';

export const JourneySection: React.FC = () => {
  const milestones: CareerMilestone[] = [
    {
      period: '2023 — PRESENT',
      level: 'LEVEL: L6 / PRINCIPAL TRACK',
      badge: 'CURRENT ROLE',
      badgeType: 'tertiary',
      role: 'Senior Machine Learning Engineer / Data Architect',
      division: 'Enterprise Telemetry & Intelligence Lab',
      description:
        'Led architectural redesign of real-time multi-variate telemetry analytics platform handling 450M+ daily events. Formulated causal attribution models that reallocated $80M in annual budget with zero manual reporting overhead. Mentored 8 mid-level and junior ML engineers.',
      tags: ['PyTorch', 'Apache Iceberg', 'Trino', 'PyMC', 'MLOps', 'Triton'],
    },
    {
      period: '2021 — 2023',
      level: 'LEVEL: L5 / SENIOR SPECIALIST',
      badge: 'COMPLETED CYCLE',
      badgeType: 'secondary',
      role: 'Quantitative Data Scientist / Analytical Modeler',
      division: 'High-Dimensional Analytics Division',
      description:
        'Built production customer lifetime value (CLV) and churn predictive engines using gradient boosted trees and survival analysis. Automated ETL pipelines across Snowflake and dbt, reducing query costs by 45% through clustering optimizations and partition pruning.',
      tags: ['Snowflake', 'dbt Core', 'XGBoost', 'Lifelines', 'Airflow', 'Polars'],
    },
    {
      period: 'GRADUATE RESEARCH',
      level: 'ACADEMIC FOCUS',
      badge: 'DISTINCTION',
      badgeType: 'outline',
      role: 'Master of Science in Computational Statistics & Applied Mathematics',
      division: 'Quantitative Systems Institute',
      description:
        'Conducted research on stochastic processes, non-parametric Bayesian estimation, and high-dimensional time-series calibration.',
      thesis: 'Stochastic Differential Equations in High-Entropy Telemetry Streams',
      publications: [
        'Rivas, A. et al. (2023). "Non-parametric Drift Detection in Distributed Sensor Arrays", IEEE Trans. Big Data.',
        'Rivas, A. (2022). "Bayesian Regularization Over Sparse Covariance Topologies", NeurIPS Workshop on Causal ML.',
      ],
      tags: ['Bayesian Inference', 'MCMC', 'Time-Series', 'Monte Carlo Methods'],
    },
  ];

  return (
    <section id="journey" className="relative w-full py-20 md:py-28 bg-[#0A0A0A] border-b border-white/10 overflow-hidden">
      {/* Ghost Backdrop Typography Watermark */}
      <div className="absolute right-0 top-10 opacity-5 pointer-events-none select-none z-0">
        <span className="font-ghost-watermark text-[140px] sm:text-[220px] md:text-[300px] text-white tracking-tighter">
          CAREER
        </span>
      </div>

      <div className="relative z-10 max-w-[1280px] mx-auto px-4 md:px-8 flex flex-col gap-12">
        {/* Section Header */}
        <div className="flex flex-col gap-3">
          <span className="font-mono text-[11px] text-gray-400 uppercase tracking-[0.3em] font-bold">
            05 // CAREER PROGRESSION &amp; MILESTONES
          </span>
          <h2 className="font-headline-lg text-[#F5F5F5] uppercase">
            Trajectory, Publications &amp; Research
          </h2>
          <div className="h-[1px] w-24 bg-white/20 mt-1" />
          <p className="font-sans text-[0.9375rem] text-gray-400 max-w-2xl">
            Demonstrated track record of delivering end-to-end analytical infrastructure, peer-reviewed
            methodologies, and production machine intelligence.
          </p>
        </div>

        {/* Timeline Stack */}
        <div className="relative flex flex-col gap-8 before:absolute before:top-4 before:bottom-4 before:left-4 md:before:left-6 before:w-[1px] before:bg-white/10">
          {milestones.map((m, index) => (
            <div key={index} className="relative pl-12 md:pl-16 flex flex-col gap-3 group">
              {/* Timeline Marker Dot */}
              <div className="absolute left-2.5 md:left-4.5 top-2 w-3.5 h-3.5 bg-black border-2 border-white group-hover:bg-white transition-colors" />

              <div className="p-6 md:p-8 bg-white/5 border border-white/10 hover:border-white/30 transition-all flex flex-col gap-5">
                {/* Milestone Top Bar */}
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-4">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-sm md:text-base font-bold text-white uppercase tracking-wider">
                      {m.period}
                    </span>
                    <span className="font-mono text-[10px] text-gray-400 uppercase tracking-widest font-bold">
                      {m.level}
                    </span>
                  </div>
                  <span
                    className={`font-mono text-[10px] px-2.5 py-0.5 font-bold uppercase tracking-[0.15em] ${
                      m.badgeType === 'tertiary'
                        ? 'bg-white text-black'
                        : m.badgeType === 'secondary'
                        ? 'bg-white/10 text-white border border-white/20'
                        : 'bg-black text-gray-300 border border-white/10'
                    }`}
                  >
                    {m.badge}
                  </span>
                </div>

                {/* Role and Division */}
                <div>
                  <h3 className="font-headline-md text-xl md:text-2xl text-[#F5F5F5] uppercase">
                    {m.role}
                  </h3>
                  <span className="font-mono text-xs text-gray-400 uppercase tracking-widest block mt-1 font-bold">
                    {m.division}
                  </span>
                </div>

                {/* Description */}
                <p className="font-sans text-[0.9375rem] text-gray-300 leading-relaxed">
                  {m.description}
                </p>

                {/* Optional Thesis / Publications */}
                {m.thesis && (
                  <div className="p-4 bg-black/60 border border-white/10 flex flex-col gap-2 font-mono text-xs">
                    <div className="flex items-center gap-2 text-white font-bold uppercase tracking-wider">
                      <BookOpen className="w-4 h-4" />
                      <span>MASTER'S THESIS:</span>
                    </div>
                    <span className="text-gray-300 pl-6 italic font-sans text-sm">
                      "{m.thesis}"
                    </span>
                  </div>
                )}

                {m.publications && (
                  <div className="flex flex-col gap-2 pt-1 font-mono text-xs">
                    <div className="flex items-center gap-2 text-white font-bold uppercase tracking-wider">
                      <Award className="w-4 h-4 text-[#a8ffd2]" />
                      <span>PEER-REVIEWED CITATIONS &amp; PAPERS:</span>
                    </div>
                    <ul className="flex flex-col gap-2 pl-6">
                      {m.publications.map((pub, pIdx) => (
                        <li key={pIdx} className="text-gray-300 font-sans text-xs flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#a8ffd2] shrink-0 mt-0.5" />
                          <span>{pub}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Skill Chips */}
                <div className="flex flex-wrap gap-2 pt-1">
                  {m.tags.map((tag, tIdx) => (
                    <span
                      key={tIdx}
                      className="px-3 py-1 bg-black/50 font-mono text-xs text-gray-300 border border-white/10"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
