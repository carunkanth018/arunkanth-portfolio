import React, { useState, useEffect } from 'react';
import { ArrowDown, Sliders, Activity, Database, Cpu, CheckCircle } from 'lucide-react';
import { ShaderBackground } from './ShaderBackground';

export const Hero: React.FC = () => {
  const roles = [
    '[ DATA SCIENTIST • ML RESEARCHER • ANALYTICAL ARCHITECT ]',
    '[ PREDICTIVE SYSTEMS ENGINEER • BAYESIAN STATISTICIAN ]',
    '[ DISTRIBUTED DATA SYSTEMS • QUANTITATIVE STRATEGIST ]',
    '[ REAL-TIME TELEMETRY • HIGH-THROUGHPUT ML ENGINES ]',
  ];

  const [currentRoleIndex, setCurrentRoleIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const fullText = roles[currentRoleIndex];
    let timer: NodeJS.Timeout;

    if (!isDeleting && displayedText !== fullText) {
      // Typing
      timer = setTimeout(() => {
        setDisplayedText(fullText.slice(0, displayedText.length + 1));
      }, 40);
    } else if (!isDeleting && displayedText === fullText) {
      // Pause at end
      timer = setTimeout(() => {
        setIsDeleting(true);
      }, 2400);
    } else if (isDeleting && displayedText !== '') {
      // Deleting
      timer = setTimeout(() => {
        setDisplayedText(fullText.slice(0, displayedText.length - 1));
      }, 20);
    } else if (isDeleting && displayedText === '') {
      // Switch to next
      setIsDeleting(false);
      setCurrentRoleIndex((prev) => (prev + 1) % roles.length);
    }

    return () => clearTimeout(timer);
  }, [displayedText, isDeleting, currentRoleIndex]);

  return (
    <section
      id="hero"
      className="relative w-full overflow-hidden bg-[#0A0A0A] pt-32 pb-16 md:pb-24 border-b border-white/10"
    >
      {/* WebGL Procedural Background Shader */}
      <ShaderBackground />

      {/* Subtle radial atmosphere */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_top,_rgba(255,255,255,0.04)_0%,_rgba(10,10,10,0.98)_75%)]" />

      {/* Ghost Backdrop Typography Watermark */}
      <div className="absolute -left-6 top-12 opacity-5 md:opacity-[0.07] pointer-events-none select-none z-0">
        <span className="font-ghost-watermark text-[140px] sm:text-[220px] md:text-[320px] text-white tracking-tighter">
          QUANT
        </span>
      </div>

      {/* Vertical Side Scroll Indicator */}
      <div className="hidden xl:flex absolute right-6 top-1/2 -translate-y-1/2 flex-col items-center gap-12 py-8 pointer-events-none z-20">
        <div className="h-24 w-[1px] bg-white/20" />
        <span className="rotate-90 whitespace-nowrap text-[10px] tracking-[0.4em] font-mono font-bold text-white/30">
          SCROLL // ARCHITECTURE
        </span>
        <div className="h-24 w-[1px] bg-white/20" />
      </div>

      <div className="relative z-10 max-w-[1280px] mx-auto px-4 md:px-8 flex flex-col gap-10">
        {/* Top Status & Telemetry Tagline */}
        <div className="flex flex-wrap items-center gap-4 text-xs font-mono tracking-[0.25em]">
          <span className="text-white font-bold">AV—025</span>
          <span className="text-white/20">/</span>
          <span className="text-gray-400">SYS_VER: 2025.1</span>
          <span className="text-white/20">/</span>
          <span className="text-[#a8ffd2] flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#a8ffd2] animate-pulse" />
            ONLINE // HIGH-DIMENSIONAL SYSTEMS
          </span>
        </div>

        {/* Dynamic Angled Core Display Header */}
        <div className="z-10 transform -rotate-1 origin-left flex flex-col gap-6 max-w-5xl">
          <div className="font-mono text-[11px] tracking-[0.3em] text-gray-400 uppercase font-bold flex items-center gap-2">
            <span>// HIGH-DIMENSIONAL DATA SYSTEMS &amp; ML ARCHITECTURE</span>
          </div>

          <h1 className="font-display-hero text-[#F5F5F5] uppercase">
            Alexander <br />
            <span className="text-stroke-white text-transparent">Rivas</span>
          </h1>

          {/* Dynamic Role Rotator */}
          <div className="flex items-center gap-3 font-mono text-sm md:text-base text-gray-300 min-h-[28px] tracking-[0.15em]">
            <span className="text-white font-bold">&gt;</span>
            <span className="text-white uppercase font-medium">
              {displayedText}
              <span className="inline-block w-2 h-4 bg-white ml-1 animate-pulse" />
            </span>
          </div>

          {/* Description with border-l-2 */}
          <p className="max-w-2xl text-base md:text-lg text-gray-400 font-light leading-relaxed border-l-2 border-white/20 pl-6">
            Architecting high-throughput machine learning engines, Bayesian causal attribution
            frameworks, and distributed lakehouse platforms. Deconstructing stochastic complexity
            into deterministic enterprise intelligence.
          </p>
        </div>

        {/* Hero Call To Actions */}
        <div className="flex flex-wrap items-center gap-4 pt-2">
          <a
            href="#projects"
            className="px-6 py-3.5 rounded bg-white text-black font-mono text-xs font-bold uppercase tracking-[0.2em] hover:bg-neutral-200 transition-all flex items-center gap-2"
          >
            <span>CASE STUDIES</span>
            <ArrowDown className="w-4 h-4" />
          </a>

          <a
            href="#skills"
            className="px-6 py-3.5 rounded bg-white/5 text-white hover:bg-white/10 border border-white/20 font-mono text-xs uppercase tracking-[0.2em] transition-all flex items-center gap-2"
          >
            <span>CAPABILITY MATRIX</span>
            <Sliders className="w-4 h-4" />
          </a>
        </div>

        {/* Live Analytics Baseline Bar - Bold Grid Layout */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4 pt-8 border-t border-white/10 items-end">
          <div className="p-5 bg-white/5 border border-white/10 hover:border-white/30 transition-colors flex flex-col justify-between h-[150px] relative group">
            <div className="flex items-center justify-between text-gray-400">
              <span className="font-mono text-[10px] tracking-[0.2em] uppercase font-bold">
                01 — PRECISION BASELINE
              </span>
              <Activity className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <div className="font-code-metric text-[#F5F5F5]">99.4%</div>
              <span className="font-mono text-[10px] tracking-[0.1em] text-[#a8ffd2] font-semibold">
                +2.1% P95 &bull; F1 STREAM SCORE
              </span>
            </div>
          </div>

          <div className="p-5 bg-white/5 border border-white/10 hover:border-white/30 transition-colors flex flex-col justify-between h-[150px] relative group">
            <div className="flex items-center justify-between text-gray-400">
              <span className="font-mono text-[10px] tracking-[0.2em] uppercase font-bold">
                02 — DAILY INGESTION
              </span>
              <Database className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <div className="font-code-metric text-[#F5F5F5]">450M+</div>
              <span className="font-mono text-[10px] tracking-[0.1em] text-gray-400 font-semibold">
                KAFKA &bull; PARQUET TICKS
              </span>
            </div>
          </div>

          <div className="p-5 bg-white/5 border border-white/10 hover:border-white/30 transition-colors flex flex-col justify-between h-[150px] relative group">
            <div className="flex items-center justify-between text-gray-400">
              <span className="font-mono text-[10px] tracking-[0.2em] uppercase font-bold">
                03 — P99 LATENCY
              </span>
              <Cpu className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <div className="font-code-metric text-[#F5F5F5]">18.2ms</div>
              <span className="font-mono text-[10px] tracking-[0.1em] text-[#a8ffd2] font-semibold">
                ONNX RUNTIME &bull; TRITON
              </span>
            </div>
          </div>

          <div className="p-5 bg-white/5 border border-white/10 hover:border-white/30 transition-colors flex flex-col justify-between h-[150px] relative group">
            <div className="flex items-center justify-between text-gray-400">
              <span className="font-mono text-[10px] tracking-[0.2em] uppercase font-bold">
                04 — PIPELINES
              </span>
              <CheckCircle className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <div className="font-code-metric text-[#F5F5F5]">14 DAGS</div>
              <span className="font-mono text-[10px] tracking-[0.1em] text-gray-400 font-semibold">
                ZERO OUTAGE &bull; DBT CORE
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
