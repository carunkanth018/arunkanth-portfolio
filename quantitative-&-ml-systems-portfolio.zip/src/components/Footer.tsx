import React, { useState, useEffect } from 'react';
import { ArrowUp, Activity } from 'lucide-react';

export const Footer: React.FC = () => {
  const [utcTime, setUtcTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setUtcTime(now.toUTCString().replace('GMT', 'UTC'));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#0A0A0A] border-t border-white/10 py-12 text-gray-400 font-mono text-xs">
      <div className="max-w-[1280px] mx-auto px-4 md:px-8 flex flex-col gap-8">
        {/* Top row: Brand + Quick Links + Back to top */}
        <div className="flex flex-wrap items-center justify-between gap-6 pb-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-black border border-white/20 flex items-center justify-center">
              <svg className="w-5 h-5" viewBox="0 0 100 100" fill="none">
                <circle cx="50" cy="30" r="10" fill="#ffffff" />
                <line x1="50" y1="30" x2="28" y2="76" stroke="#ffffff" strokeWidth="6" strokeLinecap="round" />
                <line x1="50" y1="30" x2="72" y2="76" stroke="#ffffff" strokeWidth="6" strokeLinecap="round" />
                <circle cx="28" cy="76" r="6" fill="#a8ffd2" />
                <circle cx="72" cy="76" r="6" fill="#ffffff" />
              </svg>
            </div>
            <div>
              <span className="text-[#F5F5F5] font-bold tracking-widest uppercase">ALEX RIVAS // LAB</span>
              <span className="block text-[10px] text-gray-400 font-bold uppercase tracking-wider">HIGH-DIMENSIONAL DATA SYSTEMS</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs uppercase font-bold tracking-wider">
            <a href="#hero" className="text-gray-400 hover:text-white transition-colors">HOME</a>
            <a href="#about" className="text-gray-400 hover:text-white transition-colors">ABOUT</a>
            <a href="#skills" className="text-gray-400 hover:text-white transition-colors">SKILLS</a>
            <a href="#projects" className="text-gray-400 hover:text-white transition-colors">PROJECTS</a>
            <a href="#visualizations" className="text-gray-400 hover:text-white transition-colors">WORKBENCH</a>
            <a href="#journey" className="text-gray-400 hover:text-white transition-colors">JOURNEY</a>
            <a href="#contact" className="text-gray-400 hover:text-white transition-colors">CONTACT</a>
          </div>

          <button
            onClick={scrollToTop}
            className="px-3 py-2 bg-black hover:bg-white hover:text-black text-gray-300 border border-white/10 transition-colors flex items-center gap-1.5 font-bold uppercase tracking-widest text-[10px]"
          >
            <span>TOP</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Bottom row: Live Telemetry ticker & Copyright */}
        <div className="flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div className="flex flex-wrap items-center gap-4">
            <span className="flex items-center gap-1.5 text-white font-bold">
              <span className="w-2 h-2 bg-[#a8ffd2] animate-pulse" />
              TELEMETRY: LIVE
            </span>
            <span className="text-gray-400">{utcTime}</span>
            <span className="text-gray-300">CLUSTER LATENCY: 18.2ms</span>
          </div>

          <div className="text-gray-400 tracking-wider text-[11px]">
            &copy; {new Date().getFullYear()} ALEXANDER RIVAS. ALL ALGORITHMIC RIGHTS RESERVED.
          </div>
        </div>
      </div>
    </footer>
  );
};
