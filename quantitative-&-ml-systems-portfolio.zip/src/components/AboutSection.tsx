import React, { useState } from 'react';

export const AboutSection: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number | null>(null);

  const pipelineSteps = [
    {
      step: '01. INGESTION & VALIDATION',
      tech: 'Kafka / Delta Parquet',
      connector: '↓ schema assertion',
      details: 'Strict protobuf schemas, deduplication, and streaming ingestion at 50,000+ msgs/sec.',
      color: 'text-[#00daf3]',
    },
    {
      step: '02. FEATURE STORE & TRANSFORMS',
      tech: 'dbt Core / Feast / Polars',
      connector: '↓ low-latency vector cache',
      details: 'Point-in-time correct joins, deterministic feature transformations, and Redis vector cache.',
      color: 'text-[#00daf3]',
    },
    {
      step: '03. INFERENCE ORCHESTRATOR',
      tech: 'Triton / PyTorch ONNX',
      connector: '↓ probability vector distribution',
      details: 'Model concurrency, dynamic batching, and sub-20ms P99 latency with GPU quantization.',
      color: 'text-[#89ceff]',
    },
    {
      step: '04. SEMANTIC METRIC LAYER',
      tech: 'Trino / Cube.js / DuckDB',
      connector: '↓ causal KPI aggregation',
      details: 'Governed business definitions, real-time slice-and-dice, and unified SQL query access.',
      color: 'text-[#a8ffd2]',
    },
    {
      step: '05. DECISION SURFACE & ACTUATION',
      tech: 'Custom D3 / Webhooks',
      connector: '',
      details: 'Actuator webhooks, executive telemetry cockpits, and automated downstream triggers.',
      color: 'text-[#5be9ad]',
    },
  ];

  return (
    <section id="about" className="relative w-full py-20 md:py-28 bg-[#0A0A0A] border-b border-white/10 overflow-hidden">
      {/* Ghost Backdrop Typography Watermark */}
      <div className="absolute right-0 top-12 opacity-5 pointer-events-none select-none z-0">
        <span className="font-ghost-watermark text-[140px] sm:text-[220px] md:text-[300px] text-white tracking-tighter">
          SYSTEMS
        </span>
      </div>

      <div className="relative z-10 max-w-[1280px] mx-auto px-4 md:px-8 flex flex-col gap-12">
        {/* Section Title Badge */}
        <div className="flex flex-col gap-3">
          <span className="font-mono text-[11px] text-gray-400 uppercase tracking-[0.3em] font-bold">
            01 // COGNITIVE ARCHITECTURE &amp; PHILOSOPHY
          </span>
          <h2 className="font-headline-lg text-[#F5F5F5] uppercase">
            Mathematical Rigor Meets Production Architecture
          </h2>
          <div className="h-[1px] w-24 bg-white/20 mt-1" />
        </div>

        {/* Main Layout: 3 Pillars + Framework Pipeline Matrix */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* 3 Pillars (Left Col - 7 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-5">
            <div className="p-6 bg-white/5 border border-white/10 hover:border-white/30 transition-all">
              <div className="flex items-center gap-4 pb-3">
                <span className="font-mono text-sm tracking-[0.2em] font-bold text-white bg-white/10 px-2.5 py-1 border border-white/20">
                  01
                </span>
                <h3 className="font-headline-md text-[#F5F5F5]">
                  First-Principles Decomposition
                </h3>
              </div>
              <p className="font-sans text-[0.9375rem] text-gray-400 leading-relaxed border-l-2 border-white/10 pl-4">
                Every data system begins not with tooling, but with epistemic clarity. I strip
                analytical problems down to causal primitives—evaluating stochastic entropy,
                eliminating confounds, and ensuring datasets represent actual systemic mechanics
                rather than observational artifacts.
              </p>
            </div>

            <div className="p-6 bg-white/5 border border-white/10 hover:border-white/30 transition-all">
              <div className="flex items-center gap-4 pb-3">
                <span className="font-mono text-sm tracking-[0.2em] font-bold text-white bg-white/10 px-2.5 py-1 border border-white/20">
                  02
                </span>
                <h3 className="font-headline-md text-[#F5F5F5]">
                  Algorithmic Rigor &amp; Statistical Integrity
                </h3>
              </div>
              <p className="font-sans text-[0.9375rem] text-gray-400 leading-relaxed border-l-2 border-white/10 pl-4">
                Machine learning models in mission-critical environments cannot afford hallucinated
                confidence. By enforcing Bayesian priors, explicit regularization, out-of-distribution
                drift telemetry, and robust causal inference frameworks, systems yield deterministic
                bounds rather than naive overfitted outputs.
              </p>
            </div>

            <div className="p-6 bg-white/5 border border-white/10 hover:border-white/30 transition-all">
              <div className="flex items-center gap-4 pb-3">
                <span className="font-mono text-sm tracking-[0.2em] font-bold text-white bg-white/10 px-2.5 py-1 border border-white/20">
                  03
                </span>
                <h3 className="font-headline-md text-[#F5F5F5]">
                  Closed-Loop Decision Telemetry
                </h3>
              </div>
              <p className="font-sans text-[0.9375rem] text-gray-400 leading-relaxed border-l-2 border-white/10 pl-4">
                Data has zero enterprise utility in an isolated sandbox. I build complete loop
                closures: ingestion orchestrations that feed real-time feature layers, which trigger
                deterministic inferencing engines, subsequently rendering directly into automated
                actuators or high-fidelity executive decision portals.
              </p>
            </div>
          </div>

          {/* Analytical Framework Interactive Matrix (Right Col - 5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="p-6 bg-white/5 border border-white/10 flex flex-col gap-5 h-full">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <span className="font-mono text-[11px] text-white uppercase tracking-[0.2em] font-bold">
                  Pipeline Framework
                </span>
                <span className="font-mono text-[10px] text-[#a8ffd2] border border-[#a8ffd2]/40 px-2.5 py-0.5 tracking-[0.2em] uppercase font-bold">
                  SYNCHRONIZED
                </span>
              </div>

              {/* Pipeline Visual Steps */}
              <div className="flex flex-col gap-2 font-mono text-xs">
                {pipelineSteps.map((step, idx) => (
                  <React.Fragment key={idx}>
                    <div
                      onMouseEnter={() => setActiveStep(idx)}
                      onMouseLeave={() => setActiveStep(null)}
                      className={`p-3 border transition-all cursor-pointer ${
                        activeStep === idx
                          ? 'bg-white/15 border-white text-white'
                          : 'bg-white/5 border-white/10 hover:bg-white/10 text-gray-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">&gt;</span>
                          <span className="font-semibold tracking-[0.1em] text-white">{step.step}</span>
                        </div>
                        <span className="text-gray-400 text-[10px] tracking-wider">{step.tech}</span>
                      </div>
                      {activeStep === idx && (
                        <p className="mt-2 text-xs text-gray-300 font-sans border-t border-white/10 pt-2 animate-fadeIn">
                          {step.details}
                        </p>
                      )}
                    </div>
                    {step.connector && (
                      <div className="flex justify-center text-gray-500 text-[10px] tracking-widest py-0.5">
                        {step.connector}
                      </div>
                    )}
                  </React.Fragment>
                ))}
              </div>

              {/* Vitals Quick Card */}
              <div className="mt-auto p-4 bg-black/50 border border-white/10 flex items-center justify-between">
                <div>
                  <span className="block font-mono text-[10px] text-gray-400 tracking-[0.2em] uppercase">
                    DOMAIN FOCUS
                  </span>
                  <span className="font-mono text-xs text-white font-bold tracking-wider">
                    Predictive Analytics &amp; ML Architecture
                  </span>
                </div>
                <div className="text-right">
                  <span className="block font-mono text-[10px] text-gray-400 tracking-[0.2em] uppercase">
                    STATUS
                  </span>
                  <span className="font-mono text-xs text-[#a8ffd2] font-bold tracking-wider">
                    OPEN FOR ENGAGEMENT
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
