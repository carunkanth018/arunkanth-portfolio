import React from 'react';
import { X, Download, Printer, CheckCircle2, ExternalLink } from 'lucide-react';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto bg-[#181b25] border border-[#3b494c] rounded-2xl p-6 md:p-10 flex flex-col gap-8 shadow-2xl">
        {/* Top Controls */}
        <div className="flex items-center justify-between border-b border-[#3b494c]/40 pb-4">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#a8ffd2] inline-block" />
            <span className="font-mono text-xs text-[#00daf3] uppercase tracking-wider font-semibold">
              CURRICULUM VITAE // VERIFIED SYSTEM DOSSIER
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded bg-[#262a34] hover:bg-[#31353f] text-[#dfe2ef] hover:text-[#00daf3] font-mono text-xs flex items-center gap-1.5 transition-colors border border-[#3b494c]/40"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-[#262a34] text-[#849396] hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* CV Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#3b494c]/30 pb-6">
          <div>
            <h2 className="font-headline-lg text-2xl md:text-3xl text-[#dfe2ef] uppercase tracking-tight">
              Alexander Rivas
            </h2>
            <p className="font-mono text-sm text-[#00daf3] mt-1">
              Staff / Senior Machine Learning Engineer &bull; Quantitative Data Architect
            </p>
          </div>
          <div className="flex flex-col font-mono text-xs text-[#849396] gap-1 md:text-right">
            <span>San Francisco, CA &bull; alex.rivas.analytics@gmail.com</span>
            <span>github.com/alexrivas-data &bull; linkedin.com/in/alexander-rivas-ds</span>
          </div>
        </div>

        {/* Executive Summary */}
        <div className="flex flex-col gap-2">
          <span className="font-mono text-xs text-[#89ceff] uppercase tracking-wider font-bold">
            01 // EXECUTIVE SUMMARY
          </span>
          <p className="font-sans text-sm text-[#bac9cc] leading-relaxed">
            Data systems architect and quantitative machine learning practitioner with 7+ years of
            production experience designing high-throughput analytical engines, Bayesian causal
            attribution frameworks, and distributed lakehouse environments. Proven record reducing
            false positive telemetry alerts by 74%, reallocating $80M in media investments through
            MCMC simulation, and migrating 400+ enterprise metrics to Apache Iceberg and Trino.
          </p>
        </div>

        {/* Technical Competencies Matrix */}
        <div className="flex flex-col gap-3">
          <span className="font-mono text-xs text-[#89ceff] uppercase tracking-wider font-bold">
            02 // TECHNICAL COMPETENCIES
          </span>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-xs">
            <div className="p-3 rounded bg-[#0a0e17] border border-[#3b494c]/30">
              <span className="text-[#00daf3] font-bold block mb-1">MACHINE LEARNING &amp; STATS</span>
              <span className="text-[#bac9cc] font-sans text-xs">
                PyTorch, PyMC, Stan, Triton Inference Server, ONNX Runtime, HuggingFace, Scikit-learn,
                DeepAR, Bayesian MCMC, Propensity Score Matching.
              </span>
            </div>
            <div className="p-3 rounded bg-[#0a0e17] border border-[#3b494c]/30">
              <span className="text-[#89ceff] font-bold block mb-1">DATA INFRASTRUCTURE &amp; LAKEHOUSE</span>
              <span className="text-[#bac9cc] font-sans text-xs">
                Apache Iceberg, Starburst Trino, Snowflake, dbt Core, Kafka, Delta Lake, Apache Spark,
                Polars, DuckDB, Great Expectations.
              </span>
            </div>
          </div>
        </div>

        {/* Experience */}
        <div className="flex flex-col gap-4">
          <span className="font-mono text-xs text-[#89ceff] uppercase tracking-wider font-bold">
            03 // PROFESSIONAL EXPERIENCE
          </span>

          {/* Role 1 */}
          <div className="flex flex-col gap-2 p-4 rounded-xl bg-[#1c1f29] border border-[#3b494c]/30">
            <div className="flex flex-wrap items-center justify-between gap-1">
              <span className="font-headline-sm text-base text-[#dfe2ef]">
                Senior Machine Learning Engineer &bull; Enterprise Telemetry Lab
              </span>
              <span className="font-mono text-xs text-[#a8ffd2]">2023 — Present</span>
            </div>
            <ul className="flex flex-col gap-1.5 pl-4 font-sans text-xs text-[#bac9cc] list-disc">
              <li>
                Engineered semi-supervised autoencoder + Isolation Forest anomaly detection system
                scoring 450M+ daily events at 18.2ms P99 latency.
              </li>
              <li>
                Prevented an estimated $1.4M in annualized unplanned downtime across industrial sensor
                deployments.
              </li>
              <li>
                Led company-wide migration to dbt Semantic Layer and Apache Iceberg, reducing P95
                query latency from 42s to 680ms.
              </li>
            </ul>
          </div>

          {/* Role 2 */}
          <div className="flex flex-col gap-2 p-4 rounded-xl bg-[#1c1f29] border border-[#3b494c]/30">
            <div className="flex flex-wrap items-center justify-between gap-1">
              <span className="font-headline-sm text-base text-[#dfe2ef]">
                Quantitative Data Scientist &bull; High-Dimensional Analytics Division
              </span>
              <span className="font-mono text-xs text-[#89ceff]">2021 — 2023</span>
            </div>
            <ul className="flex flex-col gap-1.5 pl-4 font-sans text-xs text-[#bac9cc] list-disc">
              <li>
                Formulated hierarchical Bayesian regression framework modeling geometric carryover
                adstock decay across $80M in distributed media spend.
              </li>
              <li>
                Identified $850k in brand search cannibalization, boosting aggregate ROAS by +32.4%.
              </li>
              <li>
                Optimized Snowflake clustered warehouses, eliminating 45% in monthly compute waste.
              </li>
            </ul>
          </div>
        </div>

        {/* Education & Honors */}
        <div className="flex flex-col gap-2">
          <span className="font-mono text-xs text-[#89ceff] uppercase tracking-wider font-bold">
            04 // ACADEMIC CREDENTIALS &amp; PUBLICATIONS
          </span>
          <div className="p-4 rounded-xl bg-[#1c1f29] border border-[#3b494c]/30 flex flex-col gap-2">
            <div className="flex items-center justify-between font-mono text-xs">
              <span className="text-[#dfe2ef] font-bold">
                M.S. Computational Statistics &amp; Applied Mathematics
              </span>
              <span className="text-[#849396]">Distinction Honors</span>
            </div>
            <p className="font-sans text-xs text-[#bac9cc]">
              Thesis: "Stochastic Differential Equations in High-Entropy Telemetry Streams"
            </p>
            <p className="font-sans text-xs text-[#849396]">
              Co-author on 2 peer-reviewed papers in IEEE Trans. Big Data and NeurIPS Workshop on Causal ML.
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-[#3b494c]/40 pt-4 font-mono text-xs">
          <span className="text-[#849396]">FINGERPRINT VERIFIED: 4A8F-912E-C5B1-7890</span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded bg-[#00e5ff] text-[#00363d] font-bold uppercase hover:bg-[#c3f5ff] transition-colors"
          >
            Close Dossier
          </button>
        </div>
      </div>
    </div>
  );
};
