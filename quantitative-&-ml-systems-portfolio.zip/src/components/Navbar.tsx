import React, { useState, useEffect } from 'react';
import { Menu, X, Download, Send, User } from 'lucide-react';

interface NavbarProps {
  onOpenResume: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenResume }) => {
  const [activeSection, setActiveSection] = useState('hero');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const navLinks = [
    { label: 'Home', href: '#hero', id: 'hero' },
    { label: 'About', href: '#about', id: 'about' },
    { label: 'Skills', href: '#skills', id: 'skills' },
    { label: 'Projects', href: '#projects', id: 'projects' },
    { label: 'Visualizations', href: '#visualizations', id: 'visualizations' },
    { label: 'Journey', href: '#journey', id: 'journey' },
    { label: 'Contact', href: '#contact', id: 'contact' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);

      const sections = navLinks.map((link) => document.getElementById(link.id));
      const scrollPos = window.scrollY + 200;

      for (let i = sections.length - 1; i >= 0; i--) {
        const sec = sections[i];
        if (sec && sec.offsetTop <= scrollPos) {
          setActiveSection(navLinks[i].id);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-200 border-b border-white/10 ${
        scrolled ? 'bg-[#0a0a0a]/95 backdrop-blur-xl shadow-2xl shadow-black' : 'bg-[#0a0a0a]/80 backdrop-blur-md'
      }`}
    >
      <div className="h-20 max-w-[1280px] mx-auto px-4 md:px-8 flex items-center justify-between gap-4">
        {/* Brand & Monogram Logo */}
        <a href="#hero" className="flex items-center gap-3 group">
          <div className="relative w-9 h-9 flex items-center justify-center rounded bg-white/5 border border-white/20 group-hover:border-white transition-colors">
            <svg
              className="w-7 h-7"
              viewBox="0 0 100 100"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <circle cx="50" cy="30" r="18" stroke="#ffffff" strokeWidth="2.5" opacity="0.3" />
              <circle cx="50" cy="30" r="10" fill="#ffffff" />
              <line x1="50" y1="30" x2="28" y2="76" stroke="#ffffff" strokeWidth="5" strokeLinecap="round" />
              <line x1="50" y1="30" x2="72" y2="76" stroke="#ffffff" strokeWidth="5" strokeLinecap="round" />
              <line x1="39" y1="58" x2="61" y2="58" stroke="#00daf3" strokeWidth="3" strokeDasharray="3 3" />
              <circle cx="50" cy="58" r="4" fill="#ffffff" />
              <circle cx="28" cy="76" r="6" fill="#a8ffd2" />
              <circle cx="72" cy="76" r="6" fill="#00daf3" />
            </svg>
          </div>

          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-mono text-sm tracking-[0.25em] text-[#f5f5f5] font-bold">
                AR—025
              </span>
              <span className="hidden sm:inline font-mono text-[10px] tracking-[0.2em] text-gray-400">
                / QUANT SYSTEMS
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#a8ffd2] animate-pulse" />
              <span className="font-mono text-[10px] tracking-[0.2em] text-gray-400 uppercase">
                SF / 37.7749° N &bull; ONLINE
              </span>
            </div>
          </div>
        </a>

        {/* Desktop Nav Links */}
        <div className="hidden xl:flex items-center">
          <nav className="flex items-center gap-6 px-4 py-1.5 rounded-full bg-white/5 border border-white/10">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.id}
                  href={link.href}
                  className={`text-[11px] tracking-[0.2em] font-medium uppercase transition-colors ${
                    isActive
                      ? 'text-white font-bold'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {link.label}
                </a>
              );
            })}
          </nav>
        </div>

        {/* Right Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenResume}
            className="hidden sm:inline-flex items-center gap-2 px-3 py-1.5 rounded text-[11px] tracking-[0.2em] font-mono text-gray-400 hover:text-white border border-white/10 hover:border-white/30 transition-all uppercase"
          >
            <Download className="w-3.5 h-3.5" />
            <span>CV</span>
          </button>

          <a
            href="#contact"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded bg-white text-black font-mono text-[11px] font-bold tracking-[0.2em] uppercase hover:bg-neutral-200 transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            <span>CONNECT</span>
          </a>

          <button
            onClick={onOpenResume}
            title="Profile & Qualifications"
            className="w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-colors"
          >
            <User className="w-4 h-4" />
          </button>

          {/* Mobile hamburger toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 text-gray-300 hover:text-white rounded bg-white/5 border border-white/10"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#0a0a0a] border-b border-white/10 px-4 py-5 flex flex-col gap-3">
          {navLinks.map((link) => (
            <a
              key={link.id}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className={`px-3 py-2 text-xs tracking-[0.2em] font-mono uppercase rounded ${
                activeSection === link.id
                  ? 'bg-white/10 text-white font-bold'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {link.label}
            </a>
          ))}
          <div className="pt-3 border-t border-white/10 flex items-center justify-between">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenResume();
              }}
              className="flex items-center gap-2 text-xs text-white font-mono tracking-[0.2em] py-1"
            >
              <Download className="w-4 h-4" />
              VIEW RESUME / CV
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
