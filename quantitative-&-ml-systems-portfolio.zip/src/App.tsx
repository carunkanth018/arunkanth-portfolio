/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { SkillsSection } from './components/SkillsSection';
import { ProjectsSection } from './components/ProjectsSection';
import { VisualizationsSection } from './components/VisualizationsSection';
import { JourneySection } from './components/JourneySection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ResumeModal } from './components/ResumeModal';

export default function App() {
  const [isResumeOpen, setIsResumeOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f5f5f5] flex flex-col font-sans selection:bg-white selection:text-black">
      {/* Top Navbar */}
      <Navbar onOpenResume={() => setIsResumeOpen(true)} />

      {/* Main Content Sections */}
      <main className="flex-1 flex flex-col w-full">
        {/* Hero Section with Shader and Role Rotator */}
        <Hero />

        {/* Section 01: Cognitive Architecture & Philosophy */}
        <AboutSection />

        {/* Section 02: Technical Taxonomy & Capability Matrix */}
        <SkillsSection />

        {/* Section 03: High-Impact Production Case Studies */}
        <ProjectsSection />

        {/* Section 04: Interactive Computational Workbench */}
        <VisualizationsSection />

        {/* Section 05: Career Progression & Milestones */}
        <JourneySection />

        {/* Section 06: Contact & Initiation Terminal */}
        <ContactSection />
      </main>

      {/* Global Footer with Live Telemetry */}
      <Footer />

      {/* Verified Dossier / Resume Modal */}
      <ResumeModal isOpen={isResumeOpen} onClose={() => setIsResumeOpen(false)} />
    </div>
  );
}
